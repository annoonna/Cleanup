# ChronoClean AI – Changelog

## v3.4.1
- Auswahlbereich im Hauptfenster gehärtet: Tabellenbereich erhält eine garantierte Mindesthöhe und kollabiert nicht mehr so leicht
- Vertikalen Splitter im Zentrum robuster gemacht und mit sichtbarerem Griff versehen, damit der Bereich besser nach oben/unten gezogen werden kann
- Standardgrößen für Docks beim Start und nach Layout-Reset nachgeschärft, damit Protokoll und Seitendocks die Mitte nicht unnötig zusammendrücken
- Zeilenhöhe und Auswahlspalte der Tabelle vergrößert
- Doppelklick auf eine Tabellenzeile schaltet die jeweilige Auswahl direkt um
- Radial-Ansicht etwas kompakter gemacht, damit der Auswahlbereich auf mittleren Fensterhöhen mehr Platz bekommt

## v3.4
- Arbeitsfläche auf andockbare Panels umgestellt: Steuerung/Profile links, Inspektor/Wachstum rechts, Protokoll unten
- Intern verschiebbare Fenster mit sicherem Standard-Layout und Button zum Zurücksetzen eingebaut
- Root-Aktionen werden pro Bereinigungslauf gebündelt, damit bei mehreren Root-Profilen nicht jedes einzeln nach Authentifizierung fragt
- Wachstums-Monitor ergänzt: vergleicht Analysen innerhalb der Sitzung und zeigt, welche sicheren Bereiche wieder wachsen oder bereits kleiner wurden
- Segmentansicht verbessert: Prozentwerte, größere Legende, Hover-Infos und Klick-Navigation von der Karte direkt zur Tabellenzeile
- Tabellenzeilen und Auswahlfelder vergrößert, damit die Liste besser bedienbar ist
- Neuer Swap/ZRAM-Expertenbereich: liest nur den aktuellen Status und zeigt eine manuelle Vorschau für ZRAM mit LZ4/Priorität 100, ohne Änderungen automatisch auszuführen

## v3.3
- Nach jeder echten Bereinigung startet automatisch eine Nachanalyse, damit keine alten Werte stehen bleiben
- Live-Freiraum auf `/` wird vor und nach der Bereinigung gemessen
- Systemd-Journal wird nicht mehr mit der kompletten Journalgröße bewertet, sondern nur mit älteren, tatsächlich vakuumierbaren Dateien
- Python-Cache-Scan ignoriert jetzt den Papierkorb-Bereich, damit gelöschte Inhalte nicht doppelt als Cache erscheinen

## v3.2
- Responsives Fensterverhalten verbessert
- Desktop-Guard greift nur noch beim Start / Screen-Wechsel statt permanent beim Ziehen
- Metrik-Karten wechseln dynamisch zwischen 4/2/1 Spalten
- Splitter wechselt bei kleineren Breiten automatisch auf vertikale Darstellung
- Tabelle bleibt horizontal scrollbar und der Hauptbereich streckt sich sauber mit

## v3
- Desktop-Guard: Fenster bleibt innerhalb der sichtbaren Desktop-Fläche
- Scrollbare Steuerseite für kleine Auflösungen
- Neue sichere Profile: npm/Yarn/pnpm, Cargo, Conda-Paketcache, Snap-Downloadcache
- Weiterhin keine Dokumente, Projekte, Datenbanken oder produktiven Containerdaten
