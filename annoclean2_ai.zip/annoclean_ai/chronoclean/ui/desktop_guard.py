from __future__ import annotations

from PyQt6.QtCore import QRect
from PyQt6.QtGui import QCursor, QGuiApplication
from PyQt6.QtWidgets import QWidget


def _pick_screen(widget: QWidget):
    screen = widget.screen()
    if screen is not None:
        return screen
    pos = widget.frameGeometry().center()
    screen = QGuiApplication.screenAt(pos)
    if screen is not None:
        return screen
    cursor_screen = QGuiApplication.screenAt(QCursor.pos())
    if cursor_screen is not None:
        return cursor_screen
    return QGuiApplication.primaryScreen()


def fit_window_to_available_geometry(
    widget: QWidget,
    margin: int = 12,
    width_ratio: float = 0.96,
    height_ratio: float = 0.94,
) -> None:
    """Clamp only when needed. Keep manual resize/drag behavior intact."""
    screen = _pick_screen(widget)
    if screen is None:
        return
    available = screen.availableGeometry()
    if available.width() <= 0 or available.height() <= 0:
        return

    frame = widget.frameGeometry()
    current_width = frame.width() or widget.width() or 1280
    current_height = frame.height() or widget.height() or 860

    max_width = max(widget.minimumWidth(), int(available.width() * width_ratio))
    max_height = max(widget.minimumHeight(), int(available.height() * height_ratio))

    target_width = min(current_width, max_width)
    target_height = min(current_height, max_height)

    min_x = available.x() + margin
    min_y = available.y() + margin
    max_x = available.x() + max(0, available.width() - target_width - margin)
    max_y = available.y() + max(0, available.height() - target_height - margin)

    x = frame.x()
    y = frame.y()

    if x < min_x:
        x = min_x
    elif x > max_x:
        x = max_x

    if y < min_y:
        y = min_y
    elif y > max_y:
        y = max_y

    target = QRect(x, y, target_width, target_height)
    if target != frame:
        widget.setGeometry(target)
