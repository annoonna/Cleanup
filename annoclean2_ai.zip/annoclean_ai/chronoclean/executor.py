from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Callable, Dict, Iterable

from .models import AnalysisResult, ExecutionPlan, ScanItem
from .policies import SAFE_CONDA_CACHE_SUFFIXES, SAFE_LOG_PATTERNS, TMP_TARGETS, iter_safe_files
from .privilege import PrivilegeManager
from .utils import path_exists_safe, path_is_symlink_safe

ProgressCb = Callable[[int, str], None]
LogCb = Callable[[str, str], None]


class SafeExecutor:
    def __init__(self, analysis: AnalysisResult):
        self.analysis = analysis
        self.items_by_key: Dict[str, ScanItem] = {item.key: item for item in analysis.items}
        self._uid = os.getuid() if hasattr(os, 'getuid') else None

    def execute(self, plan: ExecutionPlan, progress: ProgressCb | None = None, log: LogCb | None = None) -> None:
        selected = [self.items_by_key[key] for key in plan.selected_keys if key in self.items_by_key]
        total = max(1, len(selected))
        root_items = [item for item in selected if item.requires_root]
        executed_root_keys: set[str] = set()
        root_batch_done = False

        for idx, item in enumerate(selected, start=1):
            if progress:
                progress(int((idx - 1) / total * 100), f'Verarbeite: {item.title}')
            if log:
                log('info', f'Starte: {item.title}')

            if item.requires_root and not self._is_root():
                if plan.dry_run:
                    preview = item.command_preview or 'Root-Aktion (Dry-Run)'
                    if log:
                        log('info', f'[Dry-Run] Würde per Systemdialog ausführen: {preview}')
                    if progress:
                        progress(int(idx / total * 100), f'Fertig: {item.title}')
                    continue

                if item.key in executed_root_keys:
                    if progress:
                        progress(int(idx / total * 100), f'Bereits im Root-Block erledigt: {item.title}')
                    continue

                if not root_batch_done:
                    if log:
                        log('info', f'Bündele {len(root_items)} Root-Aktion(en) in eine gemeinsame Systemfreigabe.')
                    executed_root_keys = self._execute_root_batch(root_items, plan, log)
                    root_batch_done = True
                if progress:
                    progress(int(idx / total * 100), f'Fertig: {item.title}')
                continue

            try:
                self._execute_item(item, plan, log)
            except Exception as exc:
                if log:
                    log('error', f'Fehler bei {item.title}: {exc}')
            if progress:
                progress(int(idx / total * 100), f'Fertig: {item.title}')

    def _execute_item(self, item: ScanItem, plan: ExecutionPlan, log: LogCb | None) -> None:
        if item.key == 'user_trash':
            self._delete_tree_contents([Path.home() / '.local/share/Trash/files'], plan.dry_run, log)
        elif item.key == 'thumbnail_cache':
            self._delete_tree_contents([Path.home() / '.cache/thumbnails'], plan.dry_run, log)
        elif item.key == 'pip_cache':
            self._delete_tree_contents([Path.home() / '.cache/pip'], plan.dry_run, log)
        elif item.key == 'python_cache':
            self._delete_python_cache(plan.dry_run, log)
        elif item.key == 'tmp_user':
            self._delete_tmp_owned_old_files(item, plan.dry_run, log)
        elif item.key == 'firefox_cache':
            self._delete_tree_contents([Path.home() / '.cache/mozilla/firefox'], plan.dry_run, log)
        elif item.key == 'chromium_cache':
            self._delete_tree_contents([Path.home() / '.cache/chromium', Path.home() / '.cache/google-chrome'], plan.dry_run, log)
        elif item.key == 'flatpak_cache':
            self._delete_flatpak_cache(plan.dry_run, log)
        elif item.key == 'npm_cache':
            self._delete_tree_contents([Path.home() / '.npm/_cacache', Path.home() / '.cache/yarn', Path.home() / '.cache/pnpm'], plan.dry_run, log)
        elif item.key == 'cargo_cache':
            self._delete_tree_contents([Path.home() / '.cargo/registry/cache'], plan.dry_run, log)
        elif item.key == 'conda_package_cache':
            self._delete_conda_package_cache(plan.dry_run, log)
        elif item.key == 'system_logs':
            self._delete_system_log_archives(plan.dry_run, log)
        elif item.key == 'apt_cache':
            self._run_command(['apt-get', 'clean'], plan.dry_run, log)
        elif item.key == 'journal_vacuum':
            days = int(item.metadata.get('vacuum_days', plan.journal_vacuum_days))
            self._run_command(['journalctl', f'--vacuum-time={days}d'], plan.dry_run, log)
        elif item.key == 'docker_builder_cache':
            self._run_command(['docker', 'builder', 'prune', '-f', '--filter', 'until=24h'], plan.dry_run, log)
        elif item.key == 'snapd_cache':
            self._delete_tree_contents([Path('/var/lib/snapd/cache')], plan.dry_run, log)
        else:
            if log:
                log('warning', f'Unbekannter Eintrag übersprungen: {item.key}')

    def _execute_root_batch(self, items: list[ScanItem], plan: ExecutionPlan, log: LogCb | None) -> set[str]:
        ok, output = PrivilegeManager.run_elevated_items(self.analysis, items, plan)
        if not output and ok:
            output = f'Systemdialog erfolgreich für {len(items)} Root-Aktion(en).'
        for line in [line.strip() for line in output.splitlines() if line.strip()]:
            if '|' in line:
                level, message = line.split('|', 1)
                if log:
                    log(level.lower(), message.strip())
            elif log:
                log('info', line)
        if not ok and log:
            log('error', 'Root-Ausführung des gebündelten Laufs fehlgeschlagen.')
            return set()
        return {item.key for item in items}

    def _delete_tree_contents(self, roots: Iterable[Path], dry_run: bool, log: LogCb | None) -> None:
        for root in roots:
            if not path_exists_safe(root) or path_is_symlink_safe(root):
                continue
            for file in iter_safe_files(root):
                self._delete_file(file, dry_run, log)
            self._remove_empty_dirs(root, dry_run, log)

    def _delete_flatpak_cache(self, dry_run: bool, log: LogCb | None) -> None:
        roots = [Path.home() / '.var/app', Path.home() / '.cache/flatpak']
        for root in roots:
            if not path_exists_safe(root) or path_is_symlink_safe(root):
                continue
            for file in iter_safe_files(root):
                normalized = str(file).replace('\\', '/')
                if root.name == 'app' and '/cache/' not in normalized:
                    continue
                self._delete_file(file, dry_run, log)
            self._remove_empty_dirs(root, dry_run, log)

    def _delete_python_cache(self, dry_run: bool, log: LogCb | None) -> None:
        home = Path.home()
        trash_root = (Path.home() / '.local/share/Trash').resolve(strict=False)
        for dirpath, dirnames, filenames in os.walk(home, topdown=True, followlinks=False):
            current = Path(dirpath)
            try:
                if current.resolve(strict=False).is_relative_to(trash_root):
                    dirnames[:] = []
                    continue
            except Exception:
                pass
            if current.name in {'.git', '.venv', 'venv', 'node_modules'}:
                dirnames[:] = []
                continue
            if path_is_symlink_safe(current):
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if not (current / d).is_symlink()]
            if current.name == '__pycache__':
                for filename in filenames:
                    self._delete_file(current / filename, dry_run, log)
                continue
            for filename in filenames:
                if (current / filename).suffix.lower() in {'.pyc', '.pyo'}:
                    self._delete_file(current / filename, dry_run, log)
        self._remove_empty_dirs(home, dry_run, log, target_name='__pycache__')

    def _delete_tmp_owned_old_files(self, item: ScanItem, dry_run: bool, log: LogCb | None) -> None:
        min_age_days = int(item.metadata.get('min_age_days', 3))
        min_age_seconds = min_age_days * 86400
        now = int(time.time())
        for root in TMP_TARGETS:
            for file in iter_safe_files(root):
                try:
                    stat = file.stat()
                except OSError:
                    continue
                if self._uid is not None and stat.st_uid != self._uid:
                    continue
                if (now - int(stat.st_mtime)) < min_age_seconds:
                    continue
                self._delete_file(file, dry_run, log)
        for root in TMP_TARGETS:
            self._remove_empty_dirs(root, dry_run, log)

    @staticmethod
    def _is_safe_conda_cache_file(path: Path) -> bool:
        normalized = str(path).replace('\\', '/')
        return '/pkgs/cache/' in normalized or any(normalized.endswith(suffix) for suffix in SAFE_CONDA_CACHE_SUFFIXES)

    def _delete_conda_package_cache(self, dry_run: bool, log: LogCb | None) -> None:
        roots = [
            Path.home() / '.conda/pkgs',
            Path.home() / 'miniconda3/pkgs',
            Path.home() / 'anaconda3/pkgs',
            Path.home() / 'miniforge3/pkgs',
            Path.home() / 'mambaforge/pkgs',
        ]
        for root in roots:
            if not path_exists_safe(root) or path_is_symlink_safe(root):
                continue
            for file in iter_safe_files(root):
                if not self._is_safe_conda_cache_file(file):
                    continue
                self._delete_file(file, dry_run, log)
            self._remove_empty_dirs(root, dry_run, log)

    def _delete_system_log_archives(self, dry_run: bool, log: LogCb | None) -> None:
        root = Path('/var/log')
        for file in iter_safe_files(root):
            if file.name.endswith(SAFE_LOG_PATTERNS):
                self._delete_file(file, dry_run, log)
        self._remove_empty_dirs(root, dry_run, log)

    def _delete_file(self, file: Path, dry_run: bool, log: LogCb | None) -> None:
        if file.is_symlink():
            if log:
                log('warning', f'Symlink übersprungen: {file}')
            return
        if dry_run:
            if log:
                log('info', f'[Dry-Run] Würde löschen: {file}')
            return
        try:
            file.unlink(missing_ok=True)
            if log:
                log('success', f'Gelöscht: {file}')
        except IsADirectoryError:
            if log:
                log('warning', f'Ordner-Datei übersprungen: {file}')
        except Exception as exc:
            if log:
                log('error', f'Konnte nicht löschen: {file} ({exc})')

    def _remove_empty_dirs(self, root: Path, dry_run: bool, log: LogCb | None, target_name: str | None = None) -> None:
        if not path_exists_safe(root):
            return
        for dirpath, dirnames, _ in os.walk(root, topdown=False, followlinks=False):
            current = Path(dirpath)
            if path_is_symlink_safe(current):
                continue
            if target_name and current.name != target_name:
                continue
            try:
                if any(current.iterdir()):
                    continue
            except Exception:
                continue
            if current == root and target_name is None:
                continue
            if dry_run:
                if log:
                    log('info', f'[Dry-Run] Würde leeren Ordner entfernen: {current}')
                continue
            try:
                current.rmdir()
                if log:
                    log('success', f'Ordner entfernt: {current}')
            except Exception:
                continue

    def _run_command(self, command: list[str], dry_run: bool, log: LogCb | None) -> None:
        rendered = ' '.join(command)
        if dry_run:
            if log:
                log('info', f'[Dry-Run] Würde Befehl ausführen: {rendered}')
            return
        proc = subprocess.run(command, capture_output=True, text=True, check=False)
        output = (proc.stdout or '').strip()
        error = (proc.stderr or '').strip()
        if proc.returncode == 0:
            if log:
                suffix = f' | {output}' if output else ''
                log('success', f'Befehl erfolgreich: {rendered}{suffix}')
        else:
            if log:
                log('error', f'Befehl fehlgeschlagen: {rendered} | {error or output or "Unbekannter Fehler"}')

    @staticmethod
    def _is_root() -> bool:
        return hasattr(os, 'geteuid') and os.geteuid() == 0
