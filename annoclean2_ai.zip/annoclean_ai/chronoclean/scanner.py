from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Callable, Iterable, List

from .ai_engine import score_item
from .models import AnalysisResult, SampleEntry, ScanItem, ScanOptions
from .policies import (
    SAFE_CONDA_CACHE_SUFFIXES,
    SAFE_LOG_PATTERNS,
    SAFE_PYTHON_CACHE_PATTERNS,
    TMP_TARGETS,
    iter_safe_files,
    self_check,
)
from .utils import command_exists, detect_running_processes, now_iso, path_exists_safe, path_is_readable_dir, run_command

ProgressCb = Callable[[int, str], None]


class SafeScanner:
    def __init__(self, options: ScanOptions):
        self.options = options
        self._uid = os.getuid() if hasattr(os, 'getuid') else None

    def analyze(self, progress: ProgressCb | None = None) -> AnalysisResult:
        if progress:
            progress(2, 'Selbstprüfung der Sicherheitsregeln läuft ...')
        ok, messages = self_check()

        steps: list[tuple[bool, Callable[[], ScanItem]]] = [
            (self.options.include_user_trash, self.scan_user_trash),
            (self.options.include_thumbnail_cache, self.scan_thumbnail_cache),
            (self.options.include_pip_cache, self.scan_pip_cache),
            (self.options.include_python_cache, self.scan_python_cache),
            (self.options.include_tmp_user, self.scan_tmp_user_files),
            (self.options.include_firefox_cache, self.scan_firefox_cache),
            (self.options.include_chromium_cache, self.scan_chromium_cache),
            (self.options.include_flatpak_cache, self.scan_flatpak_cache),
            (self.options.include_npm_cache, self.scan_npm_cache),
            (self.options.include_cargo_cache, self.scan_cargo_cache),
            (self.options.include_conda_package_cache, self.scan_conda_package_cache),
            (self.options.include_docker_builder_cache, self.scan_docker_builder_cache),
            (self.options.include_snapd_cache, self.scan_snapd_cache),
            (self.options.include_system_logs, self.scan_system_log_archives),
            (self.options.include_apt_cache, self.scan_apt_cache),
            (self.options.include_journal_vacuum, self.scan_journal_vacuum),
        ]
        active_steps = [func for enabled, func in steps if enabled]

        items: List[ScanItem] = []
        total_steps = max(1, len(active_steps))
        for idx, func in enumerate(active_steps, start=1):
            if progress:
                progress(int((idx - 1) / total_steps * 78) + 10, f'KI analysiert: {func.__name__} ...')
            item = score_item(func())
            items.append(item)
            if progress:
                progress(int(idx / total_steps * 78) + 10, f'Analyse fertig: {item.title}')

        warnings = []
        if not ok:
            warnings.append('Selbstprüfung meldet Probleme. Ausführung bleibt blockiert.')
        if any(item.requires_root for item in items):
            warnings.append('Einige Vorschläge benötigen Root-Rechte. ChronoClean nutzt dafür nur den Systemdialog und speichert niemals Passwörter.')
        if any(item.blockers for item in items):
            warnings.append('Mindestens ein Bereich ist gerade aktiv. Die KI stuft solche Ziele vorsichtiger ein.')

        total_reclaimable = sum(item.reclaimable_bytes for item in items)
        safe_reclaimable = sum(item.reclaimable_bytes for item in items if item.risk_level.lower() == 'niedrig')

        if progress:
            progress(100, 'Analyse abgeschlossen.')

        return AnalysisResult(
            created_at=now_iso(),
            items=items,
            total_reclaimable_bytes=total_reclaimable,
            safe_reclaimable_bytes=safe_reclaimable,
            warnings=warnings,
            self_check_ok=ok,
            self_check_messages=messages,
        )

    def _collect_files(
        self,
        roots: Iterable[Path],
        predicate: Callable[[Path], bool] | None = None,
        top_n: int = 5,
    ) -> tuple[int, int, list[SampleEntry]]:
        count = 0
        total_size = 0
        top_files: list[tuple[int, str]] = []
        for root in roots:
            for file in iter_safe_files(root):
                if predicate and not predicate(file):
                    continue
                try:
                    stat = file.stat()
                except OSError:
                    continue
                count += 1
                total_size += stat.st_size
                top_files.append((stat.st_size, str(file)))
        top_files.sort(key=lambda item: item[0], reverse=True)
        samples = [SampleEntry(path=path, size_bytes=size) for size, path in top_files[:top_n]]
        return count, total_size, samples

    def _is_owned_by_user_and_old(self, path: Path, min_age_days: int) -> bool:
        try:
            stat = path.stat()
        except OSError:
            return False
        if self._uid is not None and stat.st_uid != self._uid:
            return False
        age_seconds = time.time() - stat.st_mtime
        return age_seconds >= (min_age_days * 86400)

    def _item(
        self,
        *,
        key: str,
        title: str,
        description: str,
        category: str,
        roots: list[Path],
        requires_root: bool,
        risk_level: str,
        enabled_by_default: bool,
        predicate: Callable[[Path], bool] | None = None,
        confidence: str = 'hoch',
        blockers: list[str] | None = None,
        evidence: list[str] | None = None,
        command_preview: str | None = None,
        metadata: dict | None = None,
    ) -> ScanItem:
        count, total_size, samples = self._collect_files(roots, predicate=predicate)
        primary_root = roots[0] if roots else None
        return ScanItem(
            key=key,
            title=title,
            description=description,
            category=category,
            root_path=primary_root,
            candidate_count=count,
            reclaimable_bytes=total_size,
            requires_root=requires_root,
            risk_level=risk_level,
            benefit_score=0,
            safety_score=0,
            recommendation='',
            reason='',
            enabled_by_default=enabled_by_default,
            command_preview=command_preview,
            confidence=confidence,
            blockers=blockers or [],
            evidence=evidence or [],
            sample_entries=samples,
            metadata=metadata or {'roots': [str(root) for root in roots]},
        )

    def scan_user_trash(self) -> ScanItem:
        root = Path.home() / '.local/share/Trash/files'
        return self._item(
            key='user_trash',
            title='Papierkorb des Benutzers',
            description='Dateien im Benutzer-Papierkorb sind bereits zum Löschen vorgesehen.',
            category='Benutzerdaten',
            roots=[root],
            requires_root=False,
            risk_level='niedrig',
            enabled_by_default=True,
            evidence=['Papierkorb ist ein expliziter Löschbereich.'],
        )

    def scan_thumbnail_cache(self) -> ScanItem:
        root = Path.home() / '.cache/thumbnails'
        return self._item(
            key='thumbnail_cache',
            title='Thumbnail-Cache',
            description='Vorschaubilder werden vom Desktop oder Dateimanager neu erstellt.',
            category='Cache',
            roots=[root],
            requires_root=False,
            risk_level='niedrig',
            enabled_by_default=True,
            evidence=['Vorschaubilder sind neu generierbar.'],
        )

    def scan_pip_cache(self) -> ScanItem:
        root = Path.home() / '.cache/pip'
        return self._item(
            key='pip_cache',
            title='Pip-Cache',
            description='Geladene Python-Pakete im Benutzer-Cache.',
            category='Entwickler-Cache',
            roots=[root],
            requires_root=False,
            risk_level='niedrig',
            enabled_by_default=True,
            evidence=['Pakete werden bei Bedarf erneut geladen.'],
        )

    def scan_python_cache(self) -> ScanItem:
        home = Path.home()
        count = 0
        total_size = 0
        top_files: list[tuple[int, str]] = []
        trash_root = (Path.home() / '.local/share/Trash').resolve(strict=False)
        for dirpath, dirnames, filenames in os.walk(home, topdown=True, followlinks=False):
            current = Path(dirpath)
            try:
                if current.resolve(strict=False).is_relative_to(trash_root):
                    dirnames[:] = []
                    continue
            except Exception:
                pass
            if current.name in {'.git', '.venv', 'venv', 'node_modules'}:
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if not (current / d).is_symlink()]
            if current.name == '__pycache__':
                for filename in filenames:
                    file = current / filename
                    try:
                        stat = file.stat()
                    except OSError:
                        continue
                    count += 1
                    total_size += stat.st_size
                    top_files.append((stat.st_size, str(file)))
                continue
            for filename in filenames:
                file = current / filename
                if file.suffix.lower() not in SAFE_PYTHON_CACHE_PATTERNS:
                    continue
                try:
                    stat = file.stat()
                except OSError:
                    continue
                count += 1
                total_size += stat.st_size
                top_files.append((stat.st_size, str(file)))
        top_files.sort(key=lambda entry: entry[0], reverse=True)
        return ScanItem(
            key='python_cache',
            title='Python Bytecode-Cache',
            description='`__pycache__`, `.pyc` und `.pyo` im Home-Bereich.',
            category='Entwickler-Cache',
            root_path=home,
            candidate_count=count,
            reclaimable_bytes=total_size,
            requires_root=False,
            risk_level='niedrig',
            benefit_score=0,
            safety_score=0,
            recommendation='',
            reason='',
            enabled_by_default=False,
            confidence='hoch',
            blockers=[],
            evidence=['Bytecode-Dateien werden automatisch neu erzeugt.'],
            sample_entries=[SampleEntry(path=path, size_bytes=size) for size, path in top_files[:5]],
            metadata={'roots': [str(home)]},
        )

    def scan_tmp_user_files(self) -> ScanItem:
        count = 0
        total_size = 0
        top_files: list[tuple[int, str]] = []
        for root in TMP_TARGETS:
            for file in iter_safe_files(root):
                if not self._is_owned_by_user_and_old(file, self.options.tmp_min_age_days):
                    continue
                count += 1
                try:
                    size = file.stat().st_size
                except OSError:
                    continue
                total_size += size
                top_files.append((size, str(file)))
        top_files.sort(key=lambda entry: entry[0], reverse=True)
        return ScanItem(
            key='tmp_user',
            title='Alte Temp-Dateien des Benutzers',
            description=f'Nur Benutzerdateien in /tmp und /var/tmp, älter als {self.options.tmp_min_age_days} Tage.',
            category='Temporär',
            root_path=Path('/tmp'),
            candidate_count=count,
            reclaimable_bytes=total_size,
            requires_root=False,
            risk_level='mittel',
            benefit_score=0,
            safety_score=0,
            recommendation='',
            reason='',
            enabled_by_default=False,
            confidence='mittel',
            blockers=[],
            evidence=['Nur Dateien des aktuellen Benutzers und mit Mindestalter.'],
            sample_entries=[SampleEntry(path=path, size_bytes=size) for size, path in top_files[:5]],
            metadata={'roots': [str(root) for root in TMP_TARGETS], 'min_age_days': self.options.tmp_min_age_days},
        )

    def scan_firefox_cache(self) -> ScanItem:
        root = Path.home() / '.cache/mozilla/firefox'
        running = detect_running_processes(['firefox', 'firefox-esr'])
        return self._item(
            key='firefox_cache',
            title='Firefox-Cache',
            description='Benutzer-Cache von Firefox. Tabs, Lesezeichen und Profilinhalte bleiben unberührt.',
            category='Browser-Cache',
            roots=[root],
            requires_root=False,
            risk_level='mittel' if running else 'niedrig',
            enabled_by_default=not running,
            confidence='mittel' if running else 'hoch',
            blockers=[f'Aktiver Prozess: {name}' for name in running],
            evidence=['Nur Cache-Pfad unter ~/.cache/mozilla/firefox wird betrachtet.'],
        )

    def scan_chromium_cache(self) -> ScanItem:
        roots = [Path.home() / '.cache/chromium', Path.home() / '.cache/google-chrome']
        running = detect_running_processes(['chromium', 'chrome', 'google-chrome'])
        return self._item(
            key='chromium_cache',
            title='Chromium/Chrome-Cache',
            description='Browser-Cache unter ~/.cache/chromium und ~/.cache/google-chrome.',
            category='Browser-Cache',
            roots=roots,
            requires_root=False,
            risk_level='mittel' if running else 'niedrig',
            enabled_by_default=not running,
            confidence='mittel' if running else 'hoch',
            blockers=[f'Aktiver Prozess: {name}' for name in running],
            evidence=['Nur Cache-Verzeichnisse, keine Profile, Passwörter oder Cookies.'],
        )

    def scan_flatpak_cache(self) -> ScanItem:
        roots = [Path.home() / '.var/app', Path.home() / '.cache/flatpak']
        running = detect_running_processes(['flatpak'])
        return self._item(
            key='flatpak_cache',
            title='Flatpak-Cache',
            description='Nur Benutzer-Cache unter ~/.var/app/*/cache sowie ~/.cache/flatpak.',
            category='App-Cache',
            roots=roots,
            requires_root=False,
            risk_level='mittel',
            enabled_by_default=False,
            predicate=lambda p: '/cache/' in str(p).replace('\\', '/'),
            confidence='mittel',
            blockers=[f'Aktiver Prozess: {name}' for name in running],
            evidence=['Es werden nur Cache-Unterordner berücksichtigt.'],
        )

    def scan_npm_cache(self) -> ScanItem:
        roots = [Path.home() / '.npm/_cacache', Path.home() / '.cache/yarn', Path.home() / '.cache/pnpm']
        return self._item(
            key='npm_cache',
            title='npm / Yarn / pnpm Cache',
            description='Paket-Downloadcache für Node-Entwicklung. Projekte und node_modules bleiben unberührt.',
            category='Entwickler-Cache',
            roots=roots,
            requires_root=False,
            risk_level='niedrig',
            enabled_by_default=True,
            confidence='hoch',
            evidence=['Nur Download- und Paketcache, keine Projektordner oder node_modules.'],
        )

    def scan_cargo_cache(self) -> ScanItem:
        roots = [Path.home() / '.cargo/registry/cache']
        return self._item(
            key='cargo_cache',
            title='Cargo Registry Cache',
            description='Geladene Rust-Crates unter ~/.cargo/registry/cache.',
            category='Entwickler-Cache',
            roots=roots,
            requires_root=False,
            risk_level='niedrig',
            enabled_by_default=True,
            confidence='hoch',
            evidence=['Crates können bei Bedarf erneut aus dem Registry-Cache geladen werden.'],
        )

    def _conda_cache_roots(self) -> list[Path]:
        home = Path.home()
        return [
            home / '.conda/pkgs',
            home / 'miniconda3/pkgs',
            home / 'anaconda3/pkgs',
            home / 'miniforge3/pkgs',
            home / 'mambaforge/pkgs',
        ]

    @staticmethod
    def _is_safe_conda_cache_file(path: Path) -> bool:
        normalized = str(path).replace('\\', '/')
        return '/pkgs/cache/' in normalized or any(normalized.endswith(suffix) for suffix in SAFE_CONDA_CACHE_SUFFIXES)

    def scan_conda_package_cache(self) -> ScanItem:
        roots = self._conda_cache_roots()
        running = detect_running_processes(['conda', 'mamba', 'micromamba'])
        return self._item(
            key='conda_package_cache',
            title='Conda Paketcache',
            description='Nur Paketarchive und Cache-Metadaten in Conda-Paketverzeichnissen. Environments bleiben unberührt.',
            category='Entwickler-Cache',
            roots=roots,
            requires_root=False,
            risk_level='mittel' if running else 'niedrig',
            enabled_by_default=False,
            predicate=self._is_safe_conda_cache_file,
            confidence='mittel' if running else 'hoch',
            blockers=[f'Aktiver Prozess: {name}' for name in running],
            evidence=['Nur *.conda, *.tar.bz2 und pkgs/cache-Metadaten, keine Environments oder Projektdateien.'],
        )

    def scan_docker_builder_cache(self) -> ScanItem:
        root = Path('/var/lib/docker/buildkit')
        running = detect_running_processes(['dockerd', 'docker'])
        docker_ready = command_exists('docker')
        readable = path_is_readable_dir(root)
        blockers = [f'Aktiver Prozess: {name}' for name in running]
        evidence = ['Nur BuildKit-/Builder-Cache, keine Images, Container oder Volumes.']
        if not docker_ready:
            evidence.append('Docker-CLI nicht gefunden; Ausführung bleibt deaktiviert.')
        if running:
            evidence.append('Docker-Dienst aktiv; KI stuft Bereinigung vorsichtiger ein.')
        if not readable:
            blockers.append('Analyse ohne Root nicht lesbar')
            evidence.append('Pfad ist ohne Root nicht direkt lesbar; Größe wird konservativ als 0 angezeigt.')
            count, total_size, samples = 0, 0, []
        else:
            count, total_size, samples = self._collect_files([root])
        return ScanItem(
            key='docker_builder_cache',
            title='Docker Builder Cache',
            description='Builder-/BuildKit-Cache. Keine Volumes, keine Container, keine Images.',
            category='Container',
            root_path=root,
            candidate_count=count,
            reclaimable_bytes=total_size,
            requires_root=True,
            risk_level='hoch' if running else 'mittel',
            benefit_score=0,
            safety_score=0,
            recommendation='',
            reason='',
            enabled_by_default=False,
            command_preview='docker builder prune -f --filter until=24h',
            confidence='mittel' if docker_ready else 'niedrig',
            blockers=blockers,
            evidence=evidence,
            sample_entries=samples,
            metadata={'roots': [str(root)], 'docker_ready': docker_ready, 'analysis_readable': readable},
        )

    def scan_snapd_cache(self) -> ScanItem:
        root = Path('/var/lib/snapd/cache')
        running = detect_running_processes(['snapd'])
        readable = path_is_readable_dir(root)
        evidence = ['Nur Snap-Downloadcache, keine installierten Snaps oder Benutzerdaten.']
        blockers = [f'Aktiver Prozess: {name}' for name in running]
        if not readable:
            blockers.append('Analyse ohne Root nicht lesbar')
            evidence.append('Pfad ist ohne Root nicht direkt lesbar; Größe wird konservativ als 0 angezeigt.')
            count, total_size, samples = 0, 0, []
        else:
            count, total_size, samples = self._collect_files([root])
        return ScanItem(
            key='snapd_cache',
            title='Snap Downloadcache',
            description='Nur Dateien unter /var/lib/snapd/cache. Keine installierten Pakete oder Snap-Daten.',
            category='Paketmanager',
            root_path=root,
            candidate_count=count,
            reclaimable_bytes=total_size,
            requires_root=True,
            risk_level='hoch' if running else 'mittel',
            benefit_score=0,
            safety_score=0,
            recommendation='',
            reason='',
            enabled_by_default=False,
            command_preview='gezieltes Löschen einzelner Dateien in /var/lib/snapd/cache',
            confidence='mittel',
            blockers=blockers,
            evidence=evidence,
            sample_entries=samples,
            metadata={'roots': [str(root)], 'analysis_readable': readable},
        )

    def scan_system_log_archives(self) -> ScanItem:
        root = Path('/var/log')
        return self._item(
            key='system_logs',
            title='Archivierte System-Logs',
            description='Nur rotierte/archivierte Logs wie *.gz, *.1, *.old. Aktive Logs bleiben unberührt.',
            category='System-Logs',
            roots=[root],
            requires_root=True,
            risk_level='mittel',
            enabled_by_default=False,
            predicate=lambda p: p.name.endswith(SAFE_LOG_PATTERNS),
            confidence='mittel',
            evidence=['Aktive Textlogs werden nicht abgeschnitten.'],
        )

    def scan_apt_cache(self) -> ScanItem:
        root = Path('/var/cache/apt/archives')
        return self._item(
            key='apt_cache',
            title='APT-Paketcache',
            description='Heruntergeladene .deb-Dateien. Pakete können bei Bedarf erneut geladen werden.',
            category='Paketmanager',
            roots=[root],
            requires_root=True,
            risk_level='niedrig',
            enabled_by_default=False,
            predicate=lambda p: p.suffix.lower() == '.deb',
            command_preview='apt-get clean',
            evidence=['Es wird nur der Paketcache bereinigt.'],
        )


    def scan_journal_vacuum(self) -> ScanItem:
        root = Path('/var/log/journal')
        readable = path_is_readable_dir(root)
        min_age_seconds = self.options.journal_vacuum_days * 86400
        now_ts = time.time()
        blockers: list[str] = []
        evidence = [f'Journal wird per vacuum auf {self.options.journal_vacuum_days} Tage begrenzt.']
        if not path_exists_safe(root):
            evidence.append('Journal-Verzeichnis nicht vorhanden.')
            count = 0
            estimated_size = 0
            samples: list[SampleEntry] = []
        elif not readable:
            blockers.append('Analyse ohne Root nicht lesbar')
            evidence.append('Pfad ist ohne Root nicht direkt lesbar; Freigabepotenzial wird deshalb konservativ als 0 angezeigt.')
            count = 0
            estimated_size = 0
            samples = []
        else:
            count = 0
            estimated_size = 0
            top_files: list[tuple[int, str]] = []
            for file in iter_safe_files(root):
                try:
                    stat = file.stat()
                except OSError:
                    continue
                if (now_ts - stat.st_mtime) < min_age_seconds:
                    continue
                count += 1
                estimated_size += stat.st_size
                top_files.append((stat.st_size, str(file)))
            top_files.sort(key=lambda entry: entry[0], reverse=True)
            samples = [SampleEntry(path=path, size_bytes=size) for size, path in top_files[:5]]
            if count:
                evidence.append('Schätzung basiert auf Journal-Dateien, die älter als die Behaltezeit sind.')
            else:
                evidence.append('Keine Journal-Dateien älter als die Behaltezeit gefunden.')
        return ScanItem(
            key='journal_vacuum',
            title='Systemd-Journal begrenzen',
            description=f'Ältere Journal-Einträge per `journalctl --vacuum-time={self.options.journal_vacuum_days}d` kürzen.',
            category='System-Logs',
            root_path=root,
            candidate_count=count,
            reclaimable_bytes=estimated_size,
            requires_root=True,
            risk_level='mittel',
            benefit_score=0,
            safety_score=0,
            recommendation='',
            reason='',
            enabled_by_default=False,
            command_preview=f'journalctl --vacuum-time={self.options.journal_vacuum_days}d',
            confidence='mittel',
            blockers=blockers,
            evidence=evidence,
            sample_entries=samples,
            metadata={'roots': ['/var/log/journal'], 'vacuum_days': self.options.journal_vacuum_days, 'analysis_readable': readable},
        )

    @staticmethod
    def _parse_journal_disk_usage(text: str) -> int:
        text = (text or '').strip().lower().replace(',', '.')
        for token in text.split():
            try:
                if token.endswith('k'):
                    return int(float(token[:-1]) * 1024)
                if token.endswith('m'):
                    return int(float(token[:-1]) * 1024 * 1024)
                if token.endswith('g'):
                    return int(float(token[:-1]) * 1024 * 1024 * 1024)
                if token.endswith('t'):
                    return int(float(token[:-1]) * 1024 * 1024 * 1024 * 1024)
            except ValueError:
                continue
        return 0
