from __future__ import annotations

from dataclasses import replace

from .models import ScanItem
from .utils import clamp, format_bytes


_RISK_BASE = {
    'niedrig': 92,
    'mittel': 68,
    'hoch': 36,
}


_CONFIDENCE_TEXT = {
    'hoch': 'Hohe Sicherheit: klarer Cache-/Archivcharakter.',
    'mittel': 'Mittlere Sicherheit: manuell prüfen, falls aktiv genutzt.',
    'niedrig': 'Niedrige Sicherheit: nur bei echtem Bedarf und mit Prüfung.',
}


def _size_score(size_bytes: int) -> int:
    size_mb = size_bytes / (1024 * 1024)
    if size_mb >= 8192:
        return 60
    if size_mb >= 2048:
        return 50
    if size_mb >= 512:
        return 40
    if size_mb >= 128:
        return 30
    if size_mb >= 32:
        return 20
    if size_mb > 0:
        return 10
    return 0


def score_item(item: ScanItem) -> ScanItem:
    safety_score = _RISK_BASE.get(item.risk_level.lower(), 55)
    benefit_score = _size_score(item.reclaimable_bytes)

    if item.requires_root:
        safety_score -= 12
    if item.candidate_count > 250:
        benefit_score += 8
    elif item.candidate_count > 25:
        benefit_score += 4

    if item.blockers:
        safety_score -= min(24, 8 * len(item.blockers))
    if item.confidence == 'hoch':
        safety_score += 6
    elif item.confidence == 'niedrig':
        safety_score -= 10

    safety_score = int(clamp(safety_score, 0, 100))
    benefit_score = int(clamp(benefit_score, 0, 100))
    overall = int(round((benefit_score * 0.58) + (safety_score * 0.42)))

    if item.reclaimable_bytes == 0:
        recommendation = 'Nichts zu tun'
    elif item.blockers and safety_score < 60:
        recommendation = 'Warten / App schließen'
    elif safety_score >= 84 and benefit_score >= 15:
        recommendation = 'Sicher bereinigen'
    elif safety_score >= 60 and benefit_score >= 10:
        recommendation = 'Optional sinnvoll'
    else:
        recommendation = 'Nur manuell prüfen'

    reasons = []
    reasons.append(f'Potenzial: {format_bytes(item.reclaimable_bytes)}')
    reasons.append(f'Sicherheit: {safety_score}/100')
    reasons.append(f'Nutzen: {benefit_score}/100')
    reasons.append(_CONFIDENCE_TEXT.get(item.confidence, 'Transparente Heuristik aktiv.'))
    if item.blockers:
        reasons.append('Blocker: ' + ', '.join(item.blockers))
    if item.evidence:
        reasons.append('Analyse: ' + '; '.join(item.evidence[:2]))

    return replace(
        item,
        benefit_score=overall,
        safety_score=safety_score,
        recommendation=recommendation,
        reason=' | '.join(reasons),
    )
