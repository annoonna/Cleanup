from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Iterable

from .models import AnalysisResult, ExecutionPlan, ScanItem
from .utils import command_exists, save_json


class PrivilegeManager:
    @staticmethod
    def can_elevate() -> bool:
        return command_exists('pkexec')

    @classmethod
    def run_elevated_items(
        cls,
        analysis: AnalysisResult,
        items: Iterable[ScanItem],
        plan: ExecutionPlan,
    ) -> tuple[bool, str]:
        item_list = list(items)
        if not item_list:
            return True, ''
        if not cls.can_elevate():
            return False, 'pkexec ist nicht verfügbar. Bitte die App mit Root-Rechten starten oder pkexec installieren.'

        selected_keys = [item.key for item in item_list]
        payload = {
            'analysis': AnalysisResult(
                created_at=analysis.created_at,
                items=item_list,
                total_reclaimable_bytes=sum(item.reclaimable_bytes for item in item_list),
                safe_reclaimable_bytes=sum(
                    item.reclaimable_bytes for item in item_list if item.risk_level.lower() == 'niedrig'
                ),
                warnings=[],
                self_check_ok=analysis.self_check_ok,
                self_check_messages=analysis.self_check_messages,
            ).to_dict(),
            'plan': {
                'selected_keys': selected_keys,
                'journal_vacuum_days': plan.journal_vacuum_days,
                'dry_run': plan.dry_run,
            },
        }

        with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False, encoding='utf-8') as tmp:
            tmp_path = Path(tmp.name)
        save_json(tmp_path, payload)

        command = ['pkexec', sys.executable, '-m', 'chronoclean.root_helper', str(tmp_path)]
        proc = subprocess.run(command, capture_output=True, text=True, check=False)
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass
        output = (proc.stdout or '').strip()
        errors = (proc.stderr or '').strip()
        merged = '\n'.join(part for part in [output, errors] if part).strip()
        return proc.returncode == 0, merged

    @classmethod
    def run_elevated_item(
        cls,
        analysis: AnalysisResult,
        item: ScanItem,
        plan: ExecutionPlan,
    ) -> tuple[bool, str]:
        return cls.run_elevated_items(analysis, [item], plan)
