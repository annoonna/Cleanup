from __future__ import annotations

import datetime as _dt
import json
import math
import os
import shutil
import subprocess
from pathlib import Path
from typing import Iterable


def format_bytes(size: int) -> str:
    size = max(0, int(size))
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f'{value:.1f} {unit}'
        value /= 1024
    return f'{size} B'


def percent(part: int, total: int) -> str:
    if total <= 0:
        return '0.0%'
    return f'{(part / total) * 100:.1f}%'


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec='seconds')


def is_root() -> bool:
    return hasattr(os, 'geteuid') and os.geteuid() == 0


def safe_resolve(path: Path) -> Path:
    try:
        return path.expanduser().resolve(strict=False)
    except Exception:
        return path.expanduser().absolute()


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def path_exists_safe(path: Path) -> bool:
    try:
        return path.exists()
    except Exception:
        return False


def path_is_symlink_safe(path: Path) -> bool:
    try:
        return path.is_symlink()
    except Exception:
        return True


def path_is_readable_dir(path: Path) -> bool:
    try:
        return path_exists_safe(path) and path.is_dir() and os.access(path, os.R_OK | os.X_OK)
    except Exception:
        return False


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def save_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')


def run_command(command: list[str], timeout: int = 8) -> tuple[int, str]:
    proc = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=False,
        timeout=timeout,
    )
    text = (proc.stdout or '').strip() or (proc.stderr or '').strip()
    return proc.returncode, text


def detect_running_processes(names: Iterable[str]) -> list[str]:
    found: list[str] = []
    if not command_exists('pgrep'):
        return found
    for name in names:
        proc = subprocess.run(['pgrep', '-x', name], capture_output=True, text=True, check=False)
        if proc.returncode == 0:
            found.append(name)
    return found


def format_path_list(paths: list[str], limit: int = 3) -> str:
    if not paths:
        return 'keine Beispiele'
    trimmed = paths[:limit]
    suffix = '' if len(paths) <= limit else f' … (+{len(paths) - limit} weitere)'
    return ' | '.join(trimmed) + suffix


def arc_point(cx: float, cy: float, radius: float, angle_deg: float) -> tuple[float, float]:
    angle_rad = math.radians(angle_deg)
    return cx + radius * math.cos(angle_rad), cy + radius * math.sin(angle_rad)


def get_disk_usage(path: str | Path = '/') -> tuple[int, int, int]:
    target = str(path)
    usage = shutil.disk_usage(target)
    return int(usage.total), int(usage.used), int(usage.free)
