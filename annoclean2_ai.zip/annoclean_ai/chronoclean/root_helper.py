from __future__ import annotations

import sys
from pathlib import Path

from .executor import SafeExecutor
from .models import AnalysisResult, ExecutionPlan
from .utils import load_json


def _progress(_: int, message: str) -> None:
    print(f'INFO|{message}')


def _log(level: str, message: str) -> None:
    print(f'{level.upper()}|{message}')


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print('ERROR|Pfad zur Payload fehlt.', file=sys.stderr)
        return 2

    payload_path = Path(argv[0])
    payload = load_json(payload_path)
    analysis = AnalysisResult.from_dict(payload['analysis'])
    plan_data = payload['plan']
    plan = ExecutionPlan(
        selected_keys=list(plan_data.get('selected_keys', [])),
        journal_vacuum_days=int(plan_data.get('journal_vacuum_days', 7)),
        dry_run=bool(plan_data.get('dry_run', False)),
    )
    SafeExecutor(analysis).execute(plan, progress=_progress, log=_log)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
