#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from chronoclean.models import ScanOptions
from chronoclean.scanner import SafeScanner


def main() -> int:
    options = ScanOptions(
        include_user_trash=True,
        include_thumbnail_cache=True,
        include_pip_cache=True,
        include_python_cache=False,
        include_tmp_user=False,
        include_firefox_cache=True,
        include_chromium_cache=True,
        include_flatpak_cache=False,
        include_npm_cache=True,
        include_cargo_cache=True,
        include_conda_package_cache=False,
        include_docker_builder_cache=False,
        include_snapd_cache=False,
        include_system_logs=False,
        include_apt_cache=False,
        include_journal_vacuum=False,
    )
    result = SafeScanner(options).analyze()
    print('[OK] self_check_ok =', result.self_check_ok)
    print('[OK] analyzed_items =', len(result.items))
    print('[OK] total_reclaimable =', result.total_reclaimable_bytes)
    print('[OK] item_keys =', ', '.join(item.key for item in result.items))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
