from __future__ import annotations

from dataclasses import dataclass

from .models import AnalysisResult
from .utils import format_bytes


@dataclass(slots=True)
class GrowthDelta:
    key: str
    title: str
    previous_bytes: int
    current_bytes: int

    @property
    def delta_bytes(self) -> int:
        return self.current_bytes - self.previous_bytes


class GrowthMonitor:
    """Merkt sich Analyse-Snapshots innerhalb der aktuellen App-Sitzung.

    Ziel: transparent zeigen, welche Whitelist-Bereiche nach einer Bereinigung
    oder zwischen zwei Analysen wieder wachsen. Es werden nur bereits analysierte
    Profil-Summen verglichen, keine zusätzlichen riskanten Dateizugriffe.
    """

    def __init__(self) -> None:
        self._last_snapshot: dict[str, tuple[str, int]] = {}
        self._has_snapshot = False

    def compare_and_record(self, result: AnalysisResult) -> list[GrowthDelta]:
        current = {item.key: (item.title, int(item.reclaimable_bytes)) for item in result.items}
        deltas: list[GrowthDelta] = []

        if self._has_snapshot:
            keys = sorted(set(self._last_snapshot) | set(current))
            for key in keys:
                prev_title, prev_bytes = self._last_snapshot.get(key, (current.get(key, ('Unbekannt', 0))[0], 0))
                curr_title, curr_bytes = current.get(key, (prev_title, 0))
                deltas.append(
                    GrowthDelta(
                        key=key,
                        title=curr_title or prev_title,
                        previous_bytes=int(prev_bytes),
                        current_bytes=int(curr_bytes),
                    )
                )

        self._last_snapshot = current
        self._has_snapshot = True
        return sorted(deltas, key=lambda entry: abs(entry.delta_bytes), reverse=True)

    def render_text(self, deltas: list[GrowthDelta], limit: int = 6) -> str:
        if not self._has_snapshot:
            return 'Noch keine Vergleichsdaten vorhanden.'
        if not deltas:
            return 'Erste Analyse gespeichert. Starte später erneut eine Analyse, um Wachstum zu sehen.'

        growing = [entry for entry in deltas if entry.delta_bytes > 0]
        shrinking = [entry for entry in deltas if entry.delta_bytes < 0]
        unchanged = [entry for entry in deltas if entry.delta_bytes == 0]

        lines: list[str] = []
        if growing:
            lines.append('Seit der letzten Analyse gewachsen:')
            for entry in growing[:limit]:
                lines.append(
                    f'• {entry.title}: +{format_bytes(entry.delta_bytes)} '
                    f'(jetzt {format_bytes(entry.current_bytes)}, vorher {format_bytes(entry.previous_bytes)})'
                )
        else:
            lines.append('Seit der letzten Analyse ist kein Bereich gewachsen.')

        if shrinking:
            lines.append('')
            lines.append('Kleiner geworden / erfolgreich reduziert:')
            for entry in shrinking[:limit]:
                lines.append(
                    f'• {entry.title}: -{format_bytes(abs(entry.delta_bytes))} '
                    f'(jetzt {format_bytes(entry.current_bytes)}, vorher {format_bytes(entry.previous_bytes)})'
                )

        if unchanged and not growing and not shrinking:
            lines.append('Alle überwachten Bereiche sind unverändert.')

        return '\n'.join(lines)
