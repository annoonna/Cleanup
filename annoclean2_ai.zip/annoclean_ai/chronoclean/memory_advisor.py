from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .utils import format_bytes, path_exists_safe


@dataclass(slots=True)
class SwapEntry:
    path: str
    swap_type: str
    size_bytes: int
    used_bytes: int
    priority: int


@dataclass(slots=True)
class ZramDevice:
    name: str
    disk_size_bytes: int
    used_bytes: int
    compression_algorithm: str


@dataclass(slots=True)
class MemoryAdvice:
    summary: str
    details: list[str] = field(default_factory=list)
    command_preview: list[str] = field(default_factory=list)


class MemoryAdvisor:
    @staticmethod
    def _read_int(path: Path) -> int:
        try:
            return int(path.read_text(encoding='utf-8').strip())
        except Exception:
            return 0

    @staticmethod
    def _read_text(path: Path) -> str:
        try:
            return path.read_text(encoding='utf-8').strip()
        except Exception:
            return ''

    def read_swap_entries(self) -> list[SwapEntry]:
        swaps_file = Path('/proc/swaps')
        if not path_exists_safe(swaps_file):
            return []
        lines = self._read_text(swaps_file).splitlines()
        entries: list[SwapEntry] = []
        for line in lines[1:]:
            parts = line.split()
            if len(parts) < 5:
                continue
            size_kib = int(parts[2]) if parts[2].isdigit() else 0
            used_kib = int(parts[3]) if parts[3].isdigit() else 0
            try:
                priority = int(parts[4])
            except Exception:
                priority = 0
            entries.append(
                SwapEntry(
                    path=parts[0],
                    swap_type=parts[1],
                    size_bytes=size_kib * 1024,
                    used_bytes=used_kib * 1024,
                    priority=priority,
                )
            )
        return entries

    def read_zram_devices(self) -> list[ZramDevice]:
        devices: list[ZramDevice] = []
        sys_block = Path('/sys/block')
        if not path_exists_safe(sys_block):
            return devices
        for entry in sorted(sys_block.glob('zram*')):
            devices.append(
                ZramDevice(
                    name=entry.name,
                    disk_size_bytes=self._read_int(entry / 'disksize'),
                    used_bytes=self._read_int(entry / 'mem_used_total'),
                    compression_algorithm=self._read_text(entry / 'comp_algorithm'),
                )
            )
        return devices

    def build_advice(self) -> MemoryAdvice:
        swaps = self.read_swap_entries()
        zram_devices = self.read_zram_devices()
        details: list[str] = []
        previews: list[str] = []

        if swaps:
            details.append('Aktive Swap-Ziele:')
            for entry in swaps:
                details.append(
                    f'• {entry.path} | Typ: {entry.swap_type} | Größe: {format_bytes(entry.size_bytes)} '
                    f'| Belegt: {format_bytes(entry.used_bytes)} | Priorität: {entry.priority}'
                )
        else:
            details.append('Keine aktiven Swap-Ziele erkannt.')

        if zram_devices:
            details.append('')
            details.append('Erkannte ZRAM-Geräte:')
            for device in zram_devices:
                details.append(
                    f'• {device.name} | Größe: {format_bytes(device.disk_size_bytes)} '
                    f'| RAM belegt: {format_bytes(device.used_bytes)} | Algorithmus: {device.compression_algorithm or "unbekannt"}'
                )
            summary = 'ZRAM ist bereits aktiv.'
            if any(device.compression_algorithm and 'lz4' in device.compression_algorithm for device in zram_devices):
                summary += ' LZ4 wurde erkannt.'
            else:
                summary += ' LZ4 wurde nicht eindeutig erkannt.'
        else:
            summary = 'Kein ZRAM erkannt. Für Swap-intensive Systeme wäre ZRAM als Experten-Option sinnvoll.'
            details.append('')
            details.append('Sichere Empfehlung: erst nur prüfen, nicht blind umstellen.')
            previews.extend([
                '# Beispiel für Debian/Kali mit zram-tools – nur Vorschau, nicht automatisch ausführen',
                'sudo apt install zram-tools',
                'sudo editor /etc/default/zramswap',
                'ALGO=lz4',
                'PRIORITY=100',
                '# danach Dienst neu starten oder neu booten',
            ])

        if swaps and not zram_devices and any(entry.path == '/swapfile' or entry.path.endswith('swapfile') for entry in swaps):
            details.append('')
            details.append('Hinweis: klassische Swap-Datei aktiv, aber noch kein komprimiertes ZRAM sichtbar.')

        if not previews:
            previews.append('Keine Änderung empfohlen. Aktuellen Zustand nur überwachen.')

        return MemoryAdvice(summary=summary, details=details, command_preview=previews)
