from __future__ import annotations

import os
from pathlib import Path
from typing import Iterator, Tuple

from .utils import path_exists_safe, path_is_symlink_safe, safe_resolve

HOME = Path.home()
HOME_RESOLVED = safe_resolve(HOME)

SAFE_USER_TARGETS = [
    HOME / '.local/share/Trash/files',
    HOME / '.cache/thumbnails',
    HOME / '.cache/pip',
    HOME / '.cache/mozilla/firefox',
    HOME / '.cache/chromium',
    HOME / '.cache/google-chrome',
    HOME / '.var/app',
    HOME / '.npm',
    HOME / '.cache/yarn',
    HOME / '.cache/pnpm',
    HOME / '.cargo/registry/cache',
    HOME / '.conda/pkgs',
    HOME / 'miniconda3/pkgs',
    HOME / 'anaconda3/pkgs',
    HOME / 'miniforge3/pkgs',
    HOME / 'mambaforge/pkgs',
]

TMP_TARGETS = [Path('/tmp'), Path('/var/tmp')]
SYSTEM_TARGETS = [
    Path('/var/cache/apt/archives'),
    Path('/var/log'),
    Path('/var/log/journal'),
    Path('/var/lib/docker/buildkit'),
    Path('/var/lib/snapd/cache'),
]

CRITICAL_DENYLIST = {
    '/',
    '/boot',
    '/dev',
    '/etc',
    '/bin',
    '/sbin',
    '/lib',
    '/lib64',
    '/usr',
    '/opt',
    '/proc',
    '/root',
    '/run',
    '/srv',
    '/sys',
    '/var/lib',
    '/home',
    str(HOME_RESOLVED),
}

SAFE_LOG_PATTERNS = ('.gz', '.1', '.old')
SAFE_PYTHON_CACHE_PATTERNS = ('.pyc', '.pyo')
SAFE_CONDA_CACHE_SUFFIXES = ('.conda', '.tar.bz2', '.json', '.jlap')


def is_within(child: Path, parent: Path) -> bool:
    try:
        child_r = safe_resolve(child)
        parent_r = safe_resolve(parent)
        child_r.relative_to(parent_r)
        return True
    except Exception:
        return False


def is_symlink_or_unsafe(path: Path) -> bool:
    return path_is_symlink_safe(path)


def is_dangerous_root(path: Path) -> bool:
    return str(safe_resolve(path)) in CRITICAL_DENYLIST


def is_allowed_user_target(path: Path) -> bool:
    return any(is_within(path, target) for target in SAFE_USER_TARGETS)


def is_allowed_tmp_target(path: Path) -> bool:
    return any(is_within(path, target) for target in TMP_TARGETS)


def is_allowed_system_target(path: Path) -> bool:
    return any(is_within(path, target) for target in SYSTEM_TARGETS)


def iter_safe_files(root: Path) -> Iterator[Path]:
    try:
        if not path_exists_safe(root) or is_symlink_or_unsafe(root) or is_dangerous_root(root):
            return iter(())
    except Exception:
        return iter(())

    def _iterator() -> Iterator[Path]:
        def _onerror(_exc: OSError) -> None:
            return None

        try:
            walker = os.walk(root, topdown=True, followlinks=False, onerror=_onerror)
        except Exception:
            return

        for dirpath, dirnames, filenames in walker:
            current = Path(dirpath)
            if is_symlink_or_unsafe(current):
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if not is_symlink_or_unsafe(current / d)]
            for filename in filenames:
                candidate = current / filename
                if is_symlink_or_unsafe(candidate):
                    continue
                yield candidate

    return _iterator()


def self_check() -> Tuple[bool, list[str]]:
    messages: list[str] = []
    ok = True

    for target in SAFE_USER_TARGETS + TMP_TARGETS + SYSTEM_TARGETS:
        if is_dangerous_root(target):
            ok = False
            messages.append(f'Gefährlicher Zielpfad blockiert: {target}')

    for target in SAFE_USER_TARGETS:
        if not is_within(target, HOME):
            ok = False
            messages.append(f'Unerwartetes User-Ziel erkannt: {target}')

    for target in TMP_TARGETS:
        if str(target) not in {'/tmp', '/var/tmp'}:
            ok = False
            messages.append(f'Unerwartetes Temp-Ziel erkannt: {target}')

    allowed_system_targets = {
        '/var/cache/apt/archives',
        '/var/log',
        '/var/log/journal',
        '/var/lib/docker/buildkit',
        '/var/lib/snapd/cache',
    }
    for target in SYSTEM_TARGETS:
        if str(target) not in allowed_system_targets:
            ok = False
            messages.append(f'Unerwartetes System-Ziel erkannt: {target}')

    if ok:
        messages.append('Selbstprüfung erfolgreich: Nur Whitelist-Ziele aktiv, kritische Pfade sind blockiert.')
    return ok, messages
