# ChronoClean AI v3.4.1

Ein modularer, sicherer Cleaner für Debian/Kali mit **PyQt6**, getrennter UI/Logik, Worker-Threads und transparenter Heuristik.

## Leitlinie

**Oberste Direktive: nichts kaputt machen.**

ChronoClean arbeitet deshalb bewusst konservativ:

- nur **Whitelist-Ziele**
- **keine** Dokumente, Bilder, Projekte, Datenbanken, Musik oder sonstige Nutzdaten
- **keine** Symlink-Verfolgung
- **kein** `rm -rf`
- erst **Analyse**, dann **Dry-Run**, dann bewusste Ausführung
- Root nur über **System-Authentifizierung** (`pkexec`), nie über eine eigene Passwortsammlung in der App

## Neu in v3.4.1

- **Andockbare Arbeitsfläche**
  - Steuerung/Profile links
  - Inspektor + Wachstums-Monitor rechts
  - Protokoll unten
  - Panels intern verschiebbar und auf Wunsch wieder auf Standard zurücksetzbar
- **Gebündelte Root-Freigabe pro Bereinigungslauf**
  - mehrere Root-Profile werden in einem Lauf gemeinsam angefragt statt nacheinander
  - bewusst konservativ: keine Hintergrund-Eskalation, keine Passwortspeicherung
- **Wachstums-Monitor**
  - vergleicht Analysen innerhalb der laufenden Sitzung
  - zeigt, welche sicheren Bereiche wieder wachsen oder bereits kleiner wurden
- **Verbesserte Segmentansicht**
  - Prozentwerte direkt in der Karte
  - größere Legende
  - Hover-Infos
  - Klick auf Segment springt zur Tabellenzeile
- **Auswahlbereich robuster gemacht**
  - Tabellenbereich bekommt jetzt eine garantierte Mindesthöhe
  - mittlerer Splitter wird bei zu kleiner Darstellung automatisch auf sinnvolle Größen zurückgesetzt
  - Splitter-Griff ist optisch klarer und leichter zu treffen
  - Doppelklick auf eine Tabellenzeile schaltet die Auswahl zusätzlich direkt um
- **Swap/ZRAM-Expertenbereich (nur Hinweis)**
  - liest nur den aktuellen Swap-/ZRAM-Status
  - zeigt eine manuelle Vorschau für ZRAM mit LZ4 und Priorität 100
  - führt **keine** automatische Systemänderung aus

## Sichere Zielbereiche

Standardmäßig oder optional analysierbar:

- `~/.local/share/Trash/files`
- `~/.cache/thumbnails`
- `~/.cache/pip`
- `__pycache__`, `*.pyc`, `*.pyo` im Home-Bereich
- alte, dem Benutzer gehörende Dateien in `/tmp` und `/var/tmp`
- `~/.cache/mozilla/firefox`
- `~/.cache/chromium`
- `~/.cache/google-chrome`
- `~/.var/app/*/cache`
- optional Root:
  - `/var/cache/apt/archives/*.deb`
  - `/var/log/*.gz`, `*.1`, `*.old`
  - `journalctl --vacuum-time=...`
  - `docker builder prune -f --filter until=24h`

## Was ChronoClean bewusst **nicht** löscht

- Home-Dokumente
- Bilder, Videos, Musik
- Projektordner
- Datenbanken
- Browser-Profile, Passwörter, Lesezeichen, Cookies
- Docker-Volumes
- Docker-Container
- Docker-Images
- kritische Systempfade wie `/etc`, `/usr`, `/boot`, `/home`, `/var/lib`

## Start

```bash
python3 -m venv myenv
source myenv/bin/activate
pip install -r requirements.txt
python3 main.py
```

## Root-Hinweis

Für manche Systembereiche ist Root nötig. ChronoClean verwendet dafür ausschließlich den **Systemdialog** via `pkexec`, sofern vorhanden. In v3.4.1 werden mehrere Root-Profile pro Bereinigungslauf zusammengefasst, damit nicht jedes Profil separat fragt.

## Struktur

- `chronoclean/scanner.py` – sichere Analyse
- `chronoclean/ai_engine.py` – transparente Bewertung
- `chronoclean/executor.py` – gezielte Ausführung und gebündelte Root-Läufe
- `chronoclean/privilege.py` – Root über Systemdialog
- `chronoclean/root_helper.py` – Helper für autorisierte Root-Aktionen
- `chronoclean/growth_monitor.py` – Sitzungsbasierter Wachstumsvergleich
- `chronoclean/memory_advisor.py` – Swap/ZRAM-Hinweise ohne automatische Systemänderung
- `chronoclean/ui/main_window.py` – Oberfläche mit Docking
- `chronoclean/ui/radial_map.py` – Segment-Ansicht
- `chronoclean/workers.py` – Worker-Threads gegen UI-Freezes

## Status

Getestet wurde in dieser Übergabe:

- Python-Syntaxprüfung aller Module via `py_compile`
- Scanner-Smoke-Test (`tools/smoke_test.py`)

Nicht getestet in dieser Übergabe:

- echte GUI-Darstellung, weil im Container kein PyQt6 verfügbar war
- echte Root-Ausführung via `pkexec`
- ZRAM-Aktivierung selbst, da der Bereich absichtlich nur als manuelle Experten-Vorschau implementiert ist
