APP_STYLESHEET = """
QWidget {
    background-color: #0b1020;
    color: #e5ecff;
    font-family: 'DejaVu Sans', 'Segoe UI', sans-serif;
    font-size: 13px;
}
QMainWindow, QFrame#Card {
    background-color: #121a31;
}
QLabel#Title {
    font-size: 28px;
    font-weight: 700;
    color: #f4f7ff;
}
QLabel#TitleSmall {
    font-size: 18px;
    font-weight: 700;
    color: #f4f7ff;
}
QLabel#Subtitle {
    font-size: 13px;
    color: #93a4d8;
}
QLabel#MetricValue {
    font-size: 22px;
    font-weight: 700;
    color: #ffffff;
}
QLabel#MetricHint {
    color: #9fb0e4;
    font-size: 12px;
}
QFrame#GlassCard {
    background-color: rgba(24, 34, 62, 0.95);
    border: 1px solid rgba(120, 149, 255, 0.25);
    border-radius: 18px;
}
QPushButton {
    background-color: #1b56f5;
    border: none;
    border-radius: 12px;
    padding: 10px 16px;
    color: white;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #2c67ff;
}
QPushButton:disabled {
    background-color: #33405f;
    color: #9aa8cc;
}
QPushButton#Secondary {
    background-color: #202943;
    border: 1px solid rgba(120, 149, 255, 0.35);
}
QPushButton#Danger {
    background-color: #b83d45;
}
QTableWidget {
    background-color: #0f1730;
    border: 1px solid rgba(120, 149, 255, 0.2);
    border-radius: 14px;
    gridline-color: rgba(120, 149, 255, 0.12);
    selection-background-color: rgba(59, 130, 246, 0.30);
}
QTableWidget::item {
    padding: 6px 8px;
}
QHeaderView::section {
    background-color: #162042;
    border: none;
    padding: 8px;
    color: #dce6ff;
    font-weight: 700;
}
QProgressBar {
    border-radius: 14px;
    background-color: #131d39;
    border: 1px solid rgba(120, 149, 255, 0.22);
    text-align: center;
    min-height: 24px;
    font-weight: 700;
}
QProgressBar::chunk {
    border-radius: 12px;
    background: qlineargradient(
        x1:0, y1:0, x2:1, y2:0,
        stop:0 #18a0fb,
        stop:0.5 #5b7cff,
        stop:1 #8f4dff
    );
}
QPlainTextEdit, QTextEdit, QListWidget, QSpinBox, QCheckBox, QGroupBox, QTabWidget::pane {
    border-radius: 12px;
}
QPlainTextEdit {
    background-color: #0e162d;
    border: 1px solid rgba(120, 149, 255, 0.18);
    color: #dbe6ff;
}
QCheckBox {
    spacing: 8px;
}
QSpinBox {
    background-color: #111933;
    border: 1px solid rgba(120, 149, 255, 0.2);
    padding: 6px 8px;
}
QGroupBox {
    border: 1px solid rgba(120, 149, 255, 0.18);
    margin-top: 12px;
    padding: 12px;
    background-color: rgba(12, 18, 36, 0.55);
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 6px;
    color: #a8bbf7;
}
QTabBar::tab {
    background: #162042;
    padding: 10px 14px;
    margin-right: 4px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    color: #afc0ef;
}
QTabBar::tab:selected {
    background: #22325f;
    color: #ffffff;
}
QStatusBar {
    background-color: #10172f;
    color: #c6d4fb;
}
QDockWidget {
    color: #e5ecff;
}
QDockWidget::title {
    background-color: #162042;
    text-align: left;
    padding: 8px 12px;
    border-bottom: 1px solid rgba(120, 149, 255, 0.18);
    color: #dce6ff;
    font-weight: 700;
}
QScrollArea {
    border: none;
}
QSplitter::handle {
    background-color: rgba(120, 149, 255, 0.14);
    border-radius: 6px;
}
QSplitter::handle:horizontal {
    width: 12px;
    margin: 2px 0;
}
QSplitter::handle:vertical {
    height: 12px;
    margin: 0 2px;
}
QSplitter::handle:hover {
    background-color: rgba(120, 149, 255, 0.30);
}
QScrollBar:vertical {
    background: #10172f;
    width: 12px;
    margin: 10px 0 10px 0;
    border-radius: 6px;
}
QScrollBar::handle:vertical {
    background: rgba(120, 149, 255, 0.42);
    min-height: 28px;
    border-radius: 6px;
}
QScrollBar:horizontal {
    background: #10172f;
    height: 12px;
    margin: 0 10px 0 10px;
    border-radius: 6px;
}
QScrollBar::handle:horizontal {
    background: rgba(120, 149, 255, 0.42);
    min-width: 28px;
    border-radius: 6px;
}
QScrollBar::add-line, QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
"""
