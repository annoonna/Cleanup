from __future__ import annotations

import sys

from PyQt6.QtWidgets import QApplication

from .ui.main_window import MainWindow


def run() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName('ChronoClean AI')
    window = MainWindow()
    window.show()
    return app.exec()
