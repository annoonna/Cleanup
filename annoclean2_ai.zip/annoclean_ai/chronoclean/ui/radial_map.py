from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from PyQt6.QtCore import QPointF, QRectF, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QMouseEvent, QPaintEvent, QPainter, QPainterPath, QPen
from PyQt6.QtWidgets import QToolTip, QWidget

from ..models import ScanItem
from ..utils import arc_point, format_bytes, percent


_SEGMENT_COLORS = [
    '#5B7CFF', '#20C997', '#F6C344', '#FF7A59', '#9B6BFF', '#3DD5F3', '#7DD56F', '#F36BB3'
]


@dataclass(slots=True)
class Segment:
    item: ScanItem
    start_angle: float
    span_angle: float
    color: QColor
    share_text: str


class RadialMapWidget(QWidget):
    itemActivated = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(260)
        self.setMouseTracking(True)
        self._items: list[ScanItem] = []
        self._segments: list[Segment] = []
        self._hovered: Optional[Segment] = None
        self._selected_key: Optional[str] = None
        self._center_text = 'Noch keine Analyse'
        self._total_bytes = 0

    def set_items(self, items: list[ScanItem]) -> None:
        self._items = [item for item in items if item.reclaimable_bytes > 0]
        self._rebuild_segments()
        self._total_bytes = sum(item.reclaimable_bytes for item in self._items)
        self._center_text = 'Nichts erkannt' if self._total_bytes == 0 else f'{format_bytes(self._total_bytes)}\npotentiell frei'
        if self._selected_key and not any(item.key == self._selected_key for item in self._items):
            self._selected_key = None
        self.update()

    def select_item(self, key: str | None) -> None:
        self._selected_key = key
        self.update()

    def _rebuild_segments(self) -> None:
        self._segments.clear()
        total = sum(item.reclaimable_bytes for item in self._items)
        if total <= 0:
            return
        angle = -90.0
        for index, item in enumerate(sorted(self._items, key=lambda entry: entry.reclaimable_bytes, reverse=True)):
            span = max(5.0, (item.reclaimable_bytes / total) * 360.0)
            color = QColor(_SEGMENT_COLORS[index % len(_SEGMENT_COLORS)])
            self._segments.append(
                Segment(
                    item=item,
                    start_angle=angle,
                    span_angle=span,
                    color=color,
                    share_text=percent(item.reclaimable_bytes, total),
                )
            )
            angle += span

    def paintEvent(self, event: QPaintEvent) -> None:
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor('#0f1730'))

        rect = self.rect().adjusted(18, 18, -18, -18)
        side = min(rect.width(), rect.height())
        center_rect = QRectF(
            rect.center().x() - side / 2,
            rect.center().y() - side / 2,
            side,
            side,
        )
        outer_radius = side / 2 - 8
        inner_radius = outer_radius * 0.50

        painter.setPen(QPen(QColor(255, 255, 255, 18), 1))
        for segment in self._segments:
            self._draw_segment(painter, center_rect.center(), outer_radius, inner_radius, segment)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor('#111A33'))
        painter.drawEllipse(center_rect.center(), inner_radius, inner_radius)

        painter.setPen(QColor('#EAF0FF'))
        text_rect = QRectF(
            center_rect.center().x() - inner_radius * 0.82,
            center_rect.center().y() - inner_radius * 0.48,
            inner_radius * 1.64,
            inner_radius * 0.96,
        )
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, self._center_text)

        legend_y = rect.bottom() - 74
        legend_columns = 2 if rect.width() < 760 else 3
        legend_width = rect.width() // max(1, legend_columns)
        for index, segment in enumerate(self._segments[:6]):
            row = index // legend_columns
            col = index % legend_columns
            legend_x = rect.left() + col * legend_width
            y = legend_y + row * 26
            painter.setBrush(segment.color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(legend_x, y, 14, 14, 4, 4)
            painter.setPen(QColor('#DDE6FF'))
            painter.drawText(legend_x + 20, y + 12, segment.item.title[:24])
            painter.setPen(QColor('#8FA6E9'))
            painter.drawText(legend_x + 20, y + 26, f'{segment.share_text} · {format_bytes(segment.item.reclaimable_bytes)}')

    def _draw_segment(self, painter: QPainter, center: QPointF, outer_radius: float, inner_radius: float, segment: Segment) -> None:
        start = segment.start_angle
        end = segment.start_angle + segment.span_angle
        path = QPainterPath()

        outer_start = arc_point(center.x(), center.y(), outer_radius, start)
        path.moveTo(*outer_start)
        path.arcTo(
            center.x() - outer_radius,
            center.y() - outer_radius,
            outer_radius * 2,
            outer_radius * 2,
            start,
            segment.span_angle,
        )
        inner_end = arc_point(center.x(), center.y(), inner_radius, end)
        path.lineTo(*inner_end)
        path.arcTo(
            center.x() - inner_radius,
            center.y() - inner_radius,
            inner_radius * 2,
            inner_radius * 2,
            end,
            -segment.span_angle,
        )
        path.closeSubpath()

        color = QColor(segment.color)
        if self._selected_key == segment.item.key:
            color = color.lighter(140)
            pen = QPen(QColor(255, 255, 255, 130), 2.2)
        elif self._hovered is segment:
            color = color.lighter(125)
            pen = QPen(QColor(255, 255, 255, 72), 1.6)
        else:
            pen = QPen(QColor(255, 255, 255, 22), 1.1)
        painter.setPen(pen)
        painter.setBrush(color)
        painter.drawPath(path)

        if segment.span_angle >= 24:
            mid_angle = start + segment.span_angle / 2
            label_radius = (outer_radius + inner_radius) / 2
            lx, ly = arc_point(center.x(), center.y(), label_radius, mid_angle)
            label_rect = QRectF(lx - 40, ly - 10, 80, 20)
            painter.setPen(QColor('#F7FAFF'))
            painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, segment.share_text)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        hovered = self._segment_at(event.position())
        if hovered is not self._hovered:
            self._hovered = hovered
            self.update()
        if hovered:
            blockers = ' | '.join(hovered.item.blockers) if hovered.item.blockers else 'keine aktiven Blocker'
            QToolTip.showText(
                event.globalPosition().toPoint(),
                f'{hovered.item.title}\n{hovered.share_text} · {format_bytes(hovered.item.reclaimable_bytes)}\n{hovered.item.recommendation}\n{blockers}',
                self,
            )
        else:
            QToolTip.hideText()
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            hit = self._segment_at(event.position())
            if hit:
                self._selected_key = hit.item.key
                self.itemActivated.emit(hit.item.key)
                self.update()
        super().mousePressEvent(event)

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        self._hovered = None
        QToolTip.hideText()
        self.update()
        super().leaveEvent(event)

    def _segment_at(self, pos) -> Optional[Segment]:
        rect = self.rect().adjusted(18, 18, -18, -18)
        side = min(rect.width(), rect.height())
        center_x = rect.center().x()
        center_y = rect.center().y()
        outer_radius = side / 2 - 16
        inner_radius = outer_radius * 0.50

        dx = pos.x() - center_x
        dy = pos.y() - center_y
        radius = math.sqrt(dx * dx + dy * dy)
        if radius < inner_radius or radius > outer_radius:
            return None

        logical = (math.degrees(math.atan2(dy, dx)) + 360.0) % 360.0
        for segment in self._segments:
            start = (segment.start_angle + 360.0) % 360.0
            end = (segment.start_angle + segment.span_angle + 360.0) % 360.0
            if start <= end:
                inside = start <= logical <= end
            else:
                inside = logical >= start or logical <= end
            if inside:
                return segment
        return None
