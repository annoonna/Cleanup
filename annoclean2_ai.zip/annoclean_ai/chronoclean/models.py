from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, List, Optional


@dataclass(slots=True)
class SampleEntry:
    path: str
    size_bytes: int


@dataclass(slots=True)
class ScanItem:
    key: str
    title: str
    description: str
    category: str
    root_path: Optional[Path]
    candidate_count: int
    reclaimable_bytes: int
    requires_root: bool
    risk_level: str
    benefit_score: int
    safety_score: int
    recommendation: str
    reason: str
    enabled_by_default: bool = True
    command_preview: Optional[str] = None
    confidence: str = 'mittel'
    blockers: List[str] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)
    sample_entries: List[SampleEntry] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data['root_path'] = str(self.root_path) if self.root_path else None
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'ScanItem':
        samples = [SampleEntry(**sample) for sample in data.get('sample_entries', [])]
        root_path = data.get('root_path')
        return cls(
            key=data['key'],
            title=data['title'],
            description=data['description'],
            category=data['category'],
            root_path=Path(root_path) if root_path else None,
            candidate_count=int(data['candidate_count']),
            reclaimable_bytes=int(data['reclaimable_bytes']),
            requires_root=bool(data['requires_root']),
            risk_level=data['risk_level'],
            benefit_score=int(data.get('benefit_score', 0)),
            safety_score=int(data.get('safety_score', 0)),
            recommendation=data.get('recommendation', ''),
            reason=data.get('reason', ''),
            enabled_by_default=bool(data.get('enabled_by_default', True)),
            command_preview=data.get('command_preview'),
            confidence=data.get('confidence', 'mittel'),
            blockers=list(data.get('blockers', [])),
            evidence=list(data.get('evidence', [])),
            sample_entries=samples,
            metadata=dict(data.get('metadata', {})),
        )


@dataclass(slots=True)
class AnalysisResult:
    created_at: str
    items: List[ScanItem]
    total_reclaimable_bytes: int
    safe_reclaimable_bytes: int
    warnings: List[str]
    self_check_ok: bool
    self_check_messages: List[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            'created_at': self.created_at,
            'items': [item.to_dict() for item in self.items],
            'total_reclaimable_bytes': self.total_reclaimable_bytes,
            'safe_reclaimable_bytes': self.safe_reclaimable_bytes,
            'warnings': list(self.warnings),
            'self_check_ok': self.self_check_ok,
            'self_check_messages': list(self.self_check_messages),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'AnalysisResult':
        return cls(
            created_at=data['created_at'],
            items=[ScanItem.from_dict(item) for item in data.get('items', [])],
            total_reclaimable_bytes=int(data.get('total_reclaimable_bytes', 0)),
            safe_reclaimable_bytes=int(data.get('safe_reclaimable_bytes', 0)),
            warnings=list(data.get('warnings', [])),
            self_check_ok=bool(data.get('self_check_ok', False)),
            self_check_messages=list(data.get('self_check_messages', [])),
        )


@dataclass(slots=True)
class ScanOptions:
    include_user_trash: bool = True
    include_thumbnail_cache: bool = True
    include_pip_cache: bool = True
    include_python_cache: bool = True
    include_tmp_user: bool = True
    include_firefox_cache: bool = True
    include_chromium_cache: bool = True
    include_flatpak_cache: bool = True
    include_npm_cache: bool = True
    include_cargo_cache: bool = True
    include_conda_package_cache: bool = False
    include_docker_builder_cache: bool = False
    include_snapd_cache: bool = False
    include_system_logs: bool = False
    include_apt_cache: bool = False
    include_journal_vacuum: bool = False
    tmp_min_age_days: int = 3
    journal_vacuum_days: int = 7


@dataclass(slots=True)
class ExecutionPlan:
    selected_keys: List[str]
    journal_vacuum_days: int = 7
    dry_run: bool = False
