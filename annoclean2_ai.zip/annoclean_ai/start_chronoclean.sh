#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -d myenv ]; then
  python3 -m venv myenv
fi

source myenv/bin/activate
pip install -q -r requirements.txt
python3 main.py
