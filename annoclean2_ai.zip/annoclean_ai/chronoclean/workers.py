from __future__ import annotations

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from .executor import SafeExecutor
from .models import AnalysisResult, ExecutionPlan, ScanOptions
from .scanner import SafeScanner


class AnalysisWorker(QObject):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, options: ScanOptions):
        super().__init__()
        self.options = options

    def run(self) -> None:
        try:
            result = SafeScanner(self.options).analyze(progress=self.progress.emit)
            self.finished.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class ExecutionWorker(QObject):
    progress = pyqtSignal(int, str)
    log = pyqtSignal(str, str)
    finished = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, analysis: AnalysisResult, plan: ExecutionPlan):
        super().__init__()
        self.analysis = analysis
        self.plan = plan

    def run(self) -> None:
        try:
            SafeExecutor(self.analysis).execute(
                self.plan,
                progress=self.progress.emit,
                log=self.log.emit,
            )
            self.finished.emit()
        except Exception as exc:
            self.failed.emit(str(exc))


class WorkerThreadHandle:
    def __init__(self, worker: QObject):
        self.thread = QThread()
        self.worker = worker
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)  # type: ignore[attr-defined]

    def start(self) -> None:
        self.thread.start()

    def cleanup(self) -> None:
        self.thread.quit()
        self.thread.wait(3000)
