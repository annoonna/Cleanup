from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QDockWidget,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from ..growth_monitor import GrowthMonitor
from ..memory_advisor import MemoryAdvisor
from ..models import AnalysisResult, ExecutionPlan, ScanItem, ScanOptions
from ..utils import format_bytes, get_disk_usage, is_root, percent
from ..workers import AnalysisWorker, ExecutionWorker, WorkerThreadHandle
from .desktop_guard import fit_window_to_available_geometry
from .radial_map import RadialMapWidget
from .theme import APP_STYLESHEET


class MetricCard(QFrame):
    def __init__(self, title: str, hint: str):
        super().__init__()
        self.setObjectName('GlassCard')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(4)

        self.value_label = QLabel('--')
        self.value_label.setObjectName('MetricValue')
        title_label = QLabel(title)
        title_label.setObjectName('Subtitle')
        hint_label = QLabel(hint)
        hint_label.setObjectName('MetricHint')
        hint_label.setWordWrap(True)

        layout.addWidget(title_label)
        layout.addWidget(self.value_label)
        layout.addWidget(hint_label)

    def set_value(self, value: str) -> None:
        self.value_label.setText(value)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('ChronoClean AI v3.4.1')
        self.resize(1520, 960)
        self.setMinimumSize(1080, 720)
        self.analysis_result: Optional[AnalysisResult] = None
        self.analysis_handle: Optional[WorkerThreadHandle] = None
        self.execution_handle: Optional[WorkerThreadHandle] = None
        self._geometry_guard_active = False
        self._current_metric_columns = 0
        self.last_scan_options: Optional[ScanOptions] = None
        self._post_exec_refresh_pending = False
        self._execution_free_before: Optional[int] = None
        self._default_dock_state: Optional[bytes] = None
        self._default_dock_geometry: Optional[bytes] = None
        self._default_layout_saved = False
        self.growth_monitor = GrowthMonitor()

        self._build_ui()
        self._connect_signals()
        self._apply_theme()
        self._update_runtime_status()
        self._refresh_memory_advice()
        QTimer.singleShot(0, self._guard_window_geometry)
        QTimer.singleShot(0, lambda: self._apply_responsive_layout(force=True))

    def _build_ui(self) -> None:
        self.setDockNestingEnabled(True)
        central = QWidget()
        self.setCentralWidget(central)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(14, 14, 14, 14)
        outer.setSpacing(12)

        header = QFrame()
        header.setObjectName('GlassCard')
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(20, 18, 20, 18)
        title = QLabel('ChronoClean AI v3.4.1')
        title.setObjectName('Title')
        subtitle = QLabel(
            'Andockbare Arbeitsfläche, gebündelte Root-Freigabe pro Bereinigungslauf, Wachstums-Monitor sowie robusterer Auswahlbereich mit besserer Bedienbarkeit.'
        )
        subtitle.setObjectName('Subtitle')
        subtitle.setWordWrap(True)
        header_layout.addWidget(title)
        header_layout.addWidget(subtitle)
        outer.addWidget(header)

        self.metrics_layout = QGridLayout()
        self.metrics_layout.setHorizontalSpacing(12)
        self.metrics_layout.setVerticalSpacing(12)
        self.metric_total = MetricCard('Erkannter Speichergewinn', 'Potenzial über alle aktuell analysierten Vorschläge.')
        self.metric_safe = MetricCard('Konservativ sicher', 'Freigabe in niedrig bewerteten Bereichen.')
        self.metric_items = MetricCard('Vorschläge', 'Anzahl der transparent bewerteten Reinigungsprofile.')
        self.metric_mode = MetricCard('Modus', 'Analyse zuerst, dann Dry-Run oder Bereinigung.')
        self.metric_free = MetricCard('Live-Freiraum', 'Aktuell freier Speicher auf /. Nach Bereinigung automatisch neu gemessen.')
        self.metric_cards = [self.metric_total, self.metric_safe, self.metric_items, self.metric_mode, self.metric_free]
        outer.addLayout(self.metrics_layout)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat('Bereit')
        outer.addWidget(self.progress)

        self.center_splitter = QSplitter(Qt.Orientation.Vertical)
        self.center_splitter.setChildrenCollapsible(False)
        self.center_splitter.setHandleWidth(14)
        outer.addWidget(self.center_splitter, 1)

        self.radial_map = RadialMapWidget()
        self.center_splitter.addWidget(self.radial_map)

        self.table = QTableWidget(0, 10)
        self.table.setHorizontalHeaderLabels([
            'Auswahl', 'Bereich', 'Kategorie', 'Größe', 'Risiko', 'KI-Empfehlung', 'Mehrwert', 'Sicherheit', 'Vertrauen', 'Blocker'
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(44)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.setWordWrap(False)
        self.table.setMinimumHeight(230)
        self.table.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(0, 88)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for index in range(2, 10):
            header.setSectionResizeMode(index, QHeaderView.ResizeMode.ResizeToContents)
        self.center_splitter.addWidget(self.table)
        self.center_splitter.setStretchFactor(0, 5)
        self.center_splitter.setStretchFactor(1, 4)
        self.center_splitter.setSizes([460, 320])

        self.controls_dock = self._build_controls_dock()
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.controls_dock)

        self.inspector_dock = self._build_inspector_dock()
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.inspector_dock)

        self.log_dock = self._build_log_dock()
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_dock)

        status = QStatusBar()
        self.setStatusBar(status)
        status.showMessage('Bereit')
        self.metric_mode.set_value('Analyse zuerst')
        self._refresh_live_free_metric()
        self._apply_responsive_layout(force=True)

    def _build_controls_dock(self) -> QDockWidget:
        dock = QDockWidget('Steuerung & Profile', self)
        dock.setObjectName('ChronoCleanControlsDock')
        dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )

        self.left_scroll = QScrollArea()
        self.left_scroll.setWidgetResizable(True)
        self.left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(14)

        options_box = QGroupBox('Analyse-Profile')
        opt_layout = QVBoxLayout(options_box)
        self.cb_trash = QCheckBox('Benutzer-Papierkorb')
        self.cb_thumb = QCheckBox('Thumbnail-Cache')
        self.cb_pip = QCheckBox('Pip-Cache')
        self.cb_pycache = QCheckBox('Python-Bytecode-Cache')
        self.cb_tmp = QCheckBox('Alte Temp-Dateien des Benutzers')
        self.cb_firefox = QCheckBox('Firefox-Cache')
        self.cb_chromium = QCheckBox('Chromium/Chrome-Cache')
        self.cb_flatpak = QCheckBox('Flatpak-Cache (nur Cache-Unterordner)')
        self.cb_npm = QCheckBox('npm / Yarn / pnpm Cache')
        self.cb_cargo = QCheckBox('Cargo Registry Cache')
        self.cb_conda = QCheckBox('Conda Paketcache (nur Archive/Metadaten)')
        self.cb_docker = QCheckBox('Docker Builder Cache (Root, vorsichtig)')
        self.cb_snap = QCheckBox('Snap Downloadcache (Root)')
        self.cb_syslogs = QCheckBox('Archivierte System-Logs (Root)')
        self.cb_apt = QCheckBox('APT-Cache (Root)')
        self.cb_journal = QCheckBox('Systemd-Journal begrenzen (Root)')

        defaults = [
            (self.cb_trash, True),
            (self.cb_thumb, True),
            (self.cb_pip, True),
            (self.cb_pycache, False),
            (self.cb_tmp, False),
            (self.cb_firefox, True),
            (self.cb_chromium, True),
            (self.cb_flatpak, False),
            (self.cb_npm, True),
            (self.cb_cargo, True),
            (self.cb_conda, False),
            (self.cb_docker, False),
            (self.cb_snap, False),
            (self.cb_syslogs, False),
            (self.cb_apt, False),
            (self.cb_journal, False),
        ]
        for checkbox, checked in defaults:
            checkbox.setChecked(checked)
            opt_layout.addWidget(checkbox)

        age_row = QHBoxLayout()
        age_row.addWidget(QLabel('Temp-Dateien älter als (Tage):'))
        self.spin_tmp_days = QSpinBox()
        self.spin_tmp_days.setRange(1, 365)
        self.spin_tmp_days.setValue(3)
        age_row.addWidget(self.spin_tmp_days)
        opt_layout.addLayout(age_row)

        journal_row = QHBoxLayout()
        journal_row.addWidget(QLabel('Journal behalten (Tage):'))
        self.spin_journal_days = QSpinBox()
        self.spin_journal_days.setRange(1, 365)
        self.spin_journal_days.setValue(7)
        journal_row.addWidget(self.spin_journal_days)
        opt_layout.addLayout(journal_row)
        left_layout.addWidget(options_box)

        safety_box = QGroupBox('Schutzlogik')
        safety_layout = QVBoxLayout(safety_box)
        safety_layout.addWidget(QLabel('• Keine Dokumente, Bilder, Projekte, Datenbanken oder Home-Inhalte außerhalb der Whitelist'))
        safety_layout.addWidget(QLabel('• Keine Symlink-Verfolgung'))
        safety_layout.addWidget(QLabel('• Kein rm -rf: Einzeldateien werden gezielt gelöscht, leere Ordner separat entfernt'))
        safety_layout.addWidget(QLabel('• Root nur über pkexec / Systemdialog, nie über Passwortspeicherung in der App'))
        safety_layout.addWidget(QLabel('• Root-Aktionen werden pro Bereinigungslauf gebündelt, damit nicht jedes Profil separat fragt'))
        safety_layout.addWidget(QLabel('• Panels sind andockbar und intern verschiebbar'))
        self.label_self_check = QLabel('Selbstprüfung: noch nicht ausgeführt')
        self.label_self_check.setWordWrap(True)
        safety_layout.addWidget(self.label_self_check)
        left_layout.addWidget(safety_box)

        memory_box = QGroupBox('Swap / ZRAM-Experte (nur Hinweis)')
        memory_layout = QVBoxLayout(memory_box)
        self.memory_summary = QLabel('Prüfe Speicherstatus ...')
        self.memory_summary.setWordWrap(True)
        self.memory_text = QPlainTextEdit()
        self.memory_text.setReadOnly(True)
        self.memory_text.setMinimumHeight(190)
        self.btn_refresh_memory = QPushButton('Swap/ZRAM neu prüfen')
        self.btn_refresh_memory.setObjectName('Secondary')
        memory_layout.addWidget(self.memory_summary)
        memory_layout.addWidget(self.memory_text)
        memory_layout.addWidget(self.btn_refresh_memory)
        left_layout.addWidget(memory_box)

        controls_box = QGroupBox('Steuerung')
        controls_layout = QVBoxLayout(controls_box)
        self.btn_analyze = QPushButton('KI-Analyse starten')
        self.btn_dry_run = QPushButton('Dry-Run ausführen')
        self.btn_dry_run.setObjectName('Secondary')
        self.btn_execute = QPushButton('Sicher bereinigen')
        self.btn_execute.setObjectName('Danger')
        self.btn_execute.setEnabled(False)
        self.btn_reset_layout = QPushButton('Layout zurücksetzen')
        self.btn_reset_layout.setObjectName('Secondary')
        controls_layout.addWidget(self.btn_analyze)
        controls_layout.addWidget(self.btn_dry_run)
        controls_layout.addWidget(self.btn_execute)
        controls_layout.addWidget(self.btn_reset_layout)
        left_layout.addWidget(controls_box)

        hint = QLabel('Tipp: Die drei Hauptbereiche können per Drag & Drop umgedockt oder als Floating-Fenster gelöst werden.')
        hint.setWordWrap(True)
        left_layout.addWidget(hint)
        left_layout.addStretch(1)
        self.left_scroll.setWidget(left_panel)
        dock.setWidget(self.left_scroll)
        dock.setMinimumWidth(320)
        return dock

    def _build_inspector_dock(self) -> QDockWidget:
        dock = QDockWidget('Inspektor & Wachstum', self)
        dock.setObjectName('ChronoCleanInspectorDock')
        dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        dock.setMinimumWidth(360)

        tabs = QTabWidget()

        detail_tab = QWidget()
        detail_layout = QVBoxLayout(detail_tab)
        detail_layout.setSpacing(10)
        self.detail_title = QLabel('Kein Bereich ausgewählt')
        self.detail_title.setObjectName('TitleSmall')
        self.detail_text = QPlainTextEdit()
        self.detail_text.setReadOnly(True)
        self.detail_samples = QPlainTextEdit()
        self.detail_samples.setReadOnly(True)
        self.detail_samples.setPlaceholderText('Beispiel-Dateien aus der Analyse ...')
        detail_layout.addWidget(self.detail_title)
        detail_layout.addWidget(self.detail_text)
        detail_layout.addWidget(self.detail_samples, 1)
        tabs.addTab(detail_tab, 'Inspektor')

        growth_tab = QWidget()
        growth_layout = QVBoxLayout(growth_tab)
        self.growth_title = QLabel('Wachstums-Monitor')
        self.growth_title.setObjectName('TitleSmall')
        self.growth_text = QPlainTextEdit()
        self.growth_text.setReadOnly(True)
        self.growth_text.setPlaceholderText('Nach mehreren Analysen zeigt ChronoClean hier, welche Bereiche wieder wachsen.')
        growth_layout.addWidget(self.growth_title)
        growth_layout.addWidget(self.growth_text, 1)
        tabs.addTab(growth_tab, 'Wachstum')

        dock.setWidget(tabs)
        return dock

    def _build_log_dock(self) -> QDockWidget:
        dock = QDockWidget('ChronoClean-Protokoll', self)
        dock.setObjectName('ChronoCleanLogDock')
        dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText('ChronoClean-Protokoll ...')
        dock.setWidget(self.log)
        dock.setMinimumHeight(140)
        return dock

    def _apply_theme(self) -> None:
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(APP_STYLESHEET)

    def _connect_signals(self) -> None:
        self.btn_analyze.clicked.connect(self.start_analysis)
        self.btn_dry_run.clicked.connect(lambda: self.start_execution(dry_run=True))
        self.btn_execute.clicked.connect(lambda: self.start_execution(dry_run=False))
        self.btn_reset_layout.clicked.connect(self.reset_dock_layout)
        self.btn_refresh_memory.clicked.connect(self._refresh_memory_advice)
        self.table.itemSelectionChanged.connect(self._update_inspector_from_selection)
        self.table.cellDoubleClicked.connect(self._toggle_row_checked)
        self.radial_map.itemActivated.connect(self._select_row_by_key)

    def _update_runtime_status(self) -> None:
        mode = 'Root erkannt' if is_root() else 'Benutzer-Modus'
        self.statusBar().showMessage(f'{mode} | UI und Cleaner-Logik getrennt | Worker-Threads aktiv | Docking aktiv')

    def _guard_window_geometry(self) -> None:
        if self._geometry_guard_active:
            return
        self._geometry_guard_active = True
        try:
            fit_window_to_available_geometry(self)
        finally:
            self._geometry_guard_active = False

    def showEvent(self, event) -> None:
        super().showEvent(event)
        QTimer.singleShot(0, self._guard_window_geometry)
        QTimer.singleShot(0, self._apply_responsive_layout)
        QTimer.singleShot(0, self._apply_default_dock_sizes)
        QTimer.singleShot(0, lambda: self._rebalance_center_splitter(force=True))
        handle = self.windowHandle()
        if handle is not None and not getattr(self, '_screen_signal_connected', False):
            handle.screenChanged.connect(lambda *_: QTimer.singleShot(0, self._guard_window_geometry))
            handle.screenChanged.connect(lambda *_: QTimer.singleShot(0, self._apply_responsive_layout))
            self._screen_signal_connected = True
        if not self._default_layout_saved:
            self._default_dock_state = self.saveState()
            self._default_dock_geometry = self.saveGeometry()
            self._default_layout_saved = True

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._apply_responsive_layout()
        self._rebalance_center_splitter()

    def _apply_default_dock_sizes(self) -> None:
        docks = [self.controls_dock, self.inspector_dock]
        try:
            self.resizeDocks(docks, [340, 380], Qt.Orientation.Horizontal)
            self.resizeDocks([self.log_dock], [160], Qt.Orientation.Vertical)
        except RuntimeError:
            return

    def _rebalance_center_splitter(self, force: bool = False) -> None:
        total_height = self.center_splitter.height()
        if total_height <= 0:
            return

        minimum_map = 250
        minimum_table = 230
        handle = max(1, self.center_splitter.handleWidth())
        usable_height = max(0, total_height - handle)
        if usable_height <= 0:
            return

        current_sizes = self.center_splitter.sizes()
        current_map = current_sizes[0] if len(current_sizes) > 0 else 0
        current_table = current_sizes[1] if len(current_sizes) > 1 else 0

        if not force and current_map >= minimum_map and current_table >= minimum_table:
            return

        desired_map = int(usable_height * 0.60)
        desired_table = usable_height - desired_map
        desired_map = max(minimum_map, desired_map)
        desired_table = max(minimum_table, desired_table)

        overflow = desired_map + desired_table - usable_height
        if overflow > 0:
            reducible_map = max(0, desired_map - minimum_map)
            reduce_map = min(reducible_map, overflow)
            desired_map -= reduce_map
            overflow -= reduce_map
        if overflow > 0:
            reducible_table = max(0, desired_table - minimum_table)
            reduce_table = min(reducible_table, overflow)
            desired_table -= reduce_table
            overflow -= reduce_table

        if desired_map + desired_table > 0:
            self.center_splitter.setSizes([desired_map, desired_table])

    def _toggle_row_checked(self, row: int, _column: int) -> None:
        widget = self.table.cellWidget(row, 0)
        if widget is None:
            return
        checkbox = widget.findChild(QCheckBox)
        if checkbox is None or not checkbox.isEnabled():
            return
        checkbox.setChecked(not checkbox.isChecked())
        self.table.selectRow(row)

    def _apply_responsive_layout(self, force: bool = False) -> None:
        width = max(1, self.centralWidget().width() if self.centralWidget() else self.width())
        if width < 980:
            metric_columns = 1
        elif width < 1420:
            metric_columns = 2
        else:
            metric_columns = 4

        if force or metric_columns != self._current_metric_columns:
            while self.metrics_layout.count():
                item = self.metrics_layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.setParent(None)
            for index, card in enumerate(self.metric_cards):
                row = index // metric_columns
                col = index % metric_columns
                self.metrics_layout.addWidget(card, row, col)
            self._current_metric_columns = metric_columns

        self.controls_dock.setMinimumWidth(300 if width >= 1280 else 260)
        self.inspector_dock.setMinimumWidth(340 if width >= 1280 else 300)
        self._rebalance_center_splitter()

    def _collect_options(self) -> ScanOptions:
        return ScanOptions(
            include_user_trash=self.cb_trash.isChecked(),
            include_thumbnail_cache=self.cb_thumb.isChecked(),
            include_pip_cache=self.cb_pip.isChecked(),
            include_python_cache=self.cb_pycache.isChecked(),
            include_tmp_user=self.cb_tmp.isChecked(),
            include_firefox_cache=self.cb_firefox.isChecked(),
            include_chromium_cache=self.cb_chromium.isChecked(),
            include_flatpak_cache=self.cb_flatpak.isChecked(),
            include_npm_cache=self.cb_npm.isChecked(),
            include_cargo_cache=self.cb_cargo.isChecked(),
            include_conda_package_cache=self.cb_conda.isChecked(),
            include_docker_builder_cache=self.cb_docker.isChecked(),
            include_snapd_cache=self.cb_snap.isChecked(),
            include_system_logs=self.cb_syslogs.isChecked(),
            include_apt_cache=self.cb_apt.isChecked(),
            include_journal_vacuum=self.cb_journal.isChecked(),
            tmp_min_age_days=self.spin_tmp_days.value(),
            journal_vacuum_days=self.spin_journal_days.value(),
        )

    def _refresh_memory_advice(self) -> None:
        advice = MemoryAdvisor().build_advice()
        self.memory_summary.setText(advice.summary)
        content = []
        if advice.details:
            content.extend(advice.details)
        if advice.command_preview:
            content.extend(['', 'Vorschau / bewusst manuell prüfen:', *advice.command_preview])
        self.memory_text.setPlainText('\n'.join(content))

    def reset_dock_layout(self) -> None:
        if self._default_dock_geometry:
            self.restoreGeometry(self._default_dock_geometry)
        if self._default_dock_state:
            self.restoreState(self._default_dock_state)
        self._guard_window_geometry()
        self._apply_responsive_layout(force=True)
        self._apply_default_dock_sizes()
        self._rebalance_center_splitter(force=True)
        self.append_log('info', 'Dock-Layout auf den sicheren Standard zurückgesetzt.')

    def start_analysis(self) -> None:
        self.last_scan_options = self._collect_options()
        self._set_busy(True, 'KI analysiert sichere Bereiche ...')
        if not self._post_exec_refresh_pending:
            self.log.clear()
        self.detail_text.clear()
        self.detail_samples.clear()
        self.radial_map.set_items([])
        worker = AnalysisWorker(self._collect_options())
        handle = WorkerThreadHandle(worker)
        self.analysis_handle = handle
        worker.progress.connect(self.on_progress)
        worker.finished.connect(self.on_analysis_finished)
        worker.failed.connect(self.on_worker_failed)
        worker.finished.connect(handle.cleanup)
        worker.failed.connect(handle.cleanup)
        handle.start()

    def on_progress(self, value: int, message: str) -> None:
        self.progress.setValue(value)
        self.progress.setFormat(message)
        self.statusBar().showMessage(message)

    def on_analysis_finished(self, result: AnalysisResult) -> None:
        self.analysis_result = result
        free_after = self._refresh_live_free_metric()
        growth_deltas = self.growth_monitor.compare_and_record(result)
        self.growth_text.setPlainText(self.growth_monitor.render_text(growth_deltas))
        self._populate_table(result)
        self.radial_map.set_items(result.items)
        self._rebalance_center_splitter()
        self.metric_total.set_value(format_bytes(result.total_reclaimable_bytes))
        self.metric_safe.set_value(f"{format_bytes(result.safe_reclaimable_bytes)} ({percent(result.safe_reclaimable_bytes, result.total_reclaimable_bytes)})")
        self.metric_items.set_value(str(len(result.items)))
        root_hint = 'System-Auth gebündelt' if any(item.requires_root for item in result.items) else 'Nur Benutzer-Modus nötig'
        if self._post_exec_refresh_pending:
            delta = None if self._execution_free_before is None or free_after is None else (free_after - self._execution_free_before)
            if delta is None:
                self.metric_mode.set_value('Nachanalyse abgeschlossen')
            elif delta > 0:
                self.metric_mode.set_value(f'Freiraum +{format_bytes(delta)}')
                self.append_log('success', f'Tatsächlich freigegeben auf /: {format_bytes(delta)}')
            elif delta == 0:
                self.metric_mode.set_value('Freiraum unverändert')
                self.append_log('warning', 'Nach der Bereinigung ist auf / noch kein zusätzlicher Freiraum sichtbar. Offene Prozesse oder sofort neu erzeugte Caches können das erklären.')
            else:
                self.metric_mode.set_value(f'Freiraum -{format_bytes(abs(delta))}')
                self.append_log('warning', f'Der freie Speicher auf / ist trotz Bereinigung um {format_bytes(abs(delta))} kleiner geworden. Wahrscheinlich schreibt ein anderer Prozess parallel neue Daten oder hält gelöschte Dateien noch offen.')
            self._post_exec_refresh_pending = False
            self._execution_free_before = None
        else:
            self.metric_mode.set_value(root_hint)
        self.label_self_check.setText('Selbstprüfung: ' + ' | '.join(result.self_check_messages))
        for warning in result.warnings:
            self.append_log('warning', warning)
        self.append_log('success', f'Analyse abgeschlossen: {len(result.items)} Bereiche bewertet.')
        self.btn_execute.setEnabled(bool(result.items) and result.self_check_ok)
        self.btn_dry_run.setEnabled(True)
        if result.items:
            self.table.selectRow(0)
            self.table.scrollToTop()
        self._set_busy(False, 'Analyse abgeschlossen')

    def start_execution(self, dry_run: bool) -> None:
        if not self.analysis_result:
            QMessageBox.information(self, 'Keine Analyse', 'Bitte zuerst eine Analyse starten.')
            return
        selected_keys = self._selected_keys()
        if not selected_keys:
            QMessageBox.information(self, 'Keine Auswahl', 'Bitte mindestens einen Vorschlag auswählen.')
            return

        selected_items = [item for item in self.analysis_result.items if item.key in selected_keys]
        root_items = [item for item in selected_items if item.requires_root]
        if root_items and not dry_run and not is_root():
            self.append_log('info', f'{len(root_items)} Root-Aktion(en) werden in diesem Lauf gemeinsam angefragt.')

        if not dry_run:
            answer = QMessageBox.warning(
                self,
                'Sichere Bereinigung bestätigen',
                'ChronoClean löscht nur ausgewählte, analysierte Whitelist-Bereiche. Für Root-Aktionen nutzt die App ausschließlich den Systemdialog. Root-Profile werden dabei pro Lauf gebündelt. Fortfahren?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return

        plan = ExecutionPlan(
            selected_keys=selected_keys,
            journal_vacuum_days=self.spin_journal_days.value(),
            dry_run=dry_run,
        )
        self._execution_free_before = self._refresh_live_free_metric()
        self._set_busy(True, 'Ausführung läuft ...')
        worker = ExecutionWorker(self.analysis_result, plan)
        handle = WorkerThreadHandle(worker)
        self.execution_handle = handle
        worker.progress.connect(self.on_progress)
        worker.log.connect(self.append_log)
        worker.finished.connect(lambda: self.on_execution_finished(dry_run))
        worker.failed.connect(self.on_worker_failed)
        worker.finished.connect(handle.cleanup)
        worker.failed.connect(handle.cleanup)
        handle.start()

    def on_execution_finished(self, dry_run: bool) -> None:
        mode = 'Dry-Run abgeschlossen' if dry_run else 'Bereinigung abgeschlossen'
        self.append_log('success', mode)
        if dry_run:
            self._refresh_live_free_metric()
            self._set_busy(False, mode)
            return
        self._post_exec_refresh_pending = True
        self._set_busy(True, 'Bereinigung fertig – automatische Nachanalyse läuft ...')
        self.append_log('info', 'Automatische Nachanalyse gestartet, damit keine alten Werte stehen bleiben.')
        QTimer.singleShot(250, self.start_analysis)

    def on_worker_failed(self, message: str) -> None:
        self.append_log('error', message)
        self._set_busy(False, 'Fehler')
        QMessageBox.critical(self, 'Fehler', message)

    def append_log(self, level: str, message: str) -> None:
        prefix = {
            'info': '[INFO]',
            'warning': '[WARN]',
            'error': '[FEHLER]',
            'success': '[OK]',
        }.get(level, '[LOG]')
        self.log.appendPlainText(f'{prefix} {message}')

    def _selected_keys(self) -> list[str]:
        keys: list[str] = []
        for row in range(self.table.rowCount()):
            widget = self.table.cellWidget(row, 0)
            if isinstance(widget, QWidget):
                checkbox = widget.findChild(QCheckBox)
                if checkbox and checkbox.isChecked():
                    key = checkbox.property('scan_key')
                    if isinstance(key, str):
                        keys.append(key)
        return keys

    def _populate_table(self, result: AnalysisResult) -> None:
        self.table.setRowCount(0)
        for item in result.items:
            self._add_item_row(item)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

    def _add_item_row(self, item: ScanItem) -> None:
        row = self.table.rowCount()
        self.table.insertRow(row)

        box = QCheckBox()
        default_checked = item.enabled_by_default and item.reclaimable_bytes > 0 and item.recommendation != 'Nur manuell prüfen'
        box.setChecked(default_checked)
        box.setProperty('scan_key', item.key)
        wrapper = QWidget()
        wrapper_layout = QHBoxLayout(wrapper)
        wrapper_layout.setContentsMargins(10, 0, 10, 0)
        wrapper_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wrapper_layout.addWidget(box)
        self.table.setCellWidget(row, 0, wrapper)

        title_item = QTableWidgetItem(item.title)
        title_item.setData(Qt.ItemDataRole.UserRole, item.key)
        title_item.setToolTip(item.description)
        category_item = QTableWidgetItem(item.category)
        size_item = QTableWidgetItem(format_bytes(item.reclaimable_bytes))
        risk_item = QTableWidgetItem(item.risk_level.capitalize())
        rec_item = QTableWidgetItem(item.recommendation)
        benefit_item = QTableWidgetItem(f'{item.benefit_score}/100')
        safety_item = QTableWidgetItem(f'{item.safety_score}/100')
        confidence_item = QTableWidgetItem(item.confidence.capitalize())
        blockers_item = QTableWidgetItem(', '.join(item.blockers) if item.blockers else '—')

        for col, widget_item in enumerate([
            title_item, category_item, size_item, risk_item, rec_item, benefit_item, safety_item, confidence_item, blockers_item
        ], start=1):
            self.table.setItem(row, col, widget_item)

        risk_color = {
            'niedrig': QColor('#29d07e'),
            'mittel': QColor('#f6c344'),
            'hoch': QColor('#ff6b6b'),
        }.get(item.risk_level.lower())
        if risk_color:
            self.table.item(row, 4).setForeground(risk_color)

    def _select_row_by_key(self, key: str) -> None:
        for row in range(self.table.rowCount()):
            title_item = self.table.item(row, 1)
            if title_item and title_item.data(Qt.ItemDataRole.UserRole) == key:
                self.table.selectRow(row)
                self.table.scrollToItem(title_item, QAbstractItemView.ScrollHint.PositionAtCenter)
                break

    def _update_inspector_from_selection(self) -> None:
        if not self.analysis_result:
            return
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        if not rows:
            self.radial_map.select_item(None)
            return
        row = rows[0].row()
        title_item = self.table.item(row, 1)
        if title_item is None:
            return
        key = title_item.data(Qt.ItemDataRole.UserRole)
        if not isinstance(key, str):
            return
        self.radial_map.select_item(key)
        match = next((item for item in self.analysis_result.items if item.key == key), None)
        if not match:
            return
        self.detail_title.setText(match.title)
        details = [
            match.description,
            '',
            f'Kategorie: {match.category}',
            f'Potenzial: {format_bytes(match.reclaimable_bytes)}',
            f'Empfehlung: {match.recommendation}',
            f'Risiko: {match.risk_level.capitalize()}',
            f'Sicherheit: {match.safety_score}/100',
            f'Vertrauen: {match.confidence.capitalize()}',
            f"Root nötig: {'Ja' if match.requires_root else 'Nein'}",
            '',
            'Begründung:',
            match.reason,
        ]
        if match.command_preview:
            details.extend(['', f'Befehlsvorschau: {match.command_preview}'])
        if match.evidence:
            details.extend(['', 'Analyse-Evidenz:', *[f'• {entry}' for entry in match.evidence]])
        if match.blockers:
            details.extend(['', 'Blocker:', *[f'• {entry}' for entry in match.blockers]])
        self.detail_text.setPlainText('\n'.join(details))

        if match.sample_entries:
            sample_lines = ['Größte Beispiel-Dateien aus der Analyse:']
            for sample in match.sample_entries:
                sample_lines.append(f'• {format_bytes(sample.size_bytes)}  {sample.path}')
            self.detail_samples.setPlainText('\n'.join(sample_lines))
        else:
            self.detail_samples.setPlainText('Keine Beispiel-Dateien vorhanden oder Bereich arbeitet primär befehlsbasiert.')

    def _refresh_live_free_metric(self) -> Optional[int]:
        try:
            _total, _used, free = get_disk_usage('/')
        except Exception as exc:
            self.metric_free.set_value('unbekannt')
            self.append_log('warning', f'Freiraum konnte nicht gelesen werden: {exc}')
            return None
        self.metric_free.set_value(format_bytes(free))
        return free

    def _set_busy(self, busy: bool, message: str) -> None:
        self.btn_analyze.setEnabled(not busy)
        self.btn_dry_run.setEnabled((not busy) and self.analysis_result is not None)
        self.btn_execute.setEnabled((not busy) and bool(self.analysis_result) and self.analysis_result.self_check_ok)
        self.btn_reset_layout.setEnabled(not busy)
        self.btn_refresh_memory.setEnabled(not busy)
        self.progress.setFormat(message)
        self.statusBar().showMessage(message)
